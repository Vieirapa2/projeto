﻿using System;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Security.Cryptography;
using System.Xml;

namespace Worldcup
{
    internal class Program
    {

        static void Main(string[] args)

        {
            string[] GrupoA = new string[2];
            string[] GrupoB = new string[2];
            string[] GrupoC = new string[2];
            string[] GrupoD = new string[2];
            string[] GrupoE = new string[2];
            string[] GrupoF = new string[2];
            string[] GrupoH = new string[2];
            string[] GrupoG = new string[2];

            string jogoQuarta1 = "";
            string jogoQuarta2 = "";
            string jogoQuarta3 = "";
            string jogoQuarta4 = "";
            string jogoQuarta5 = "";
            string jogoQuarta6 = "";
            string jogoQuarta7 = "";
            string jogoQuarta8 = "";

            string jogoSemi1 = "";
            string jogoSemi2 = "";
            string jogoSemi3 = "";
            string jogoSemi4 = "";

            string jogoFinal1 = "";
            string jogoFinal2 = "";

            string jogoVencedor = "";

            string Qatar = "Qatar";
            string Senegal = "Senegal";
            string Equador = "Equador";
            string Holanda = "Holanda";
            string Inglaterra = "Inglaterra";
            string Estados_Unidos = "Estados Unidos";
            string Irã = "Irã";
            string Gales = "País Gales"; 
            string Argentina = "Argentina";
            string Polonia = "Polónia";
            string Mexico = "México";
            string Arabia = "Arabia";
            string Franca = "França";
            string Australia = "Australia";
            string Tunisia = "Tunisia";
            string Dinamarca = "Dinamarca";
            string Japao = "Japão";
            string Espanha = "Espanha";
            string Alemanha = "Alemanha";
            string Costa_Rica = "Costa Rica";
            string Marrocos = "Marrocos";
            string Croacia = "Croácia";
            string Belgica = "Belgica";
            string Canada = "Canada";
            string Brasil = "Brasil";
            string Suica = "Suiça";
            string Camaroes = "Camarões";
            string Servia = "Sérvia";
            string Portugal = "Portugal";
            string Coreia_sul = "Coreia do Sul";
            string Uruguai = "Uruguai";
            string Gana = "Gana";





            Console.WriteLine(" |------------------------------------------Mundial 2022-----------------------------------------|");
            Console.WriteLine("  _________________         _________________         _________________         _________________ ");
            Console.WriteLine(" |     Group  A    |       |     Group   B   |       |     Group C     |       |     Group D     |");
            Console.WriteLine(" |-----------------|       |-----------------|       |-----------------|       |-----------------|");
            Console.WriteLine(" |      Qatar      |       |    Inglaterra   |       |   Argentina     |       |      França     |");
            Console.WriteLine(" |     Ecuador     |       |  Estados unidos |       |    Polónia      |       |    Austrália    |");
            Console.WriteLine(" |     Senegal     |       |       Irã       |       |     México      |       |     Tunísia     |");
            Console.WriteLine(" |     Holanda     |       |      Gales      |       |  Arábia Saudita |       |    Diniamarca   |");
            Console.WriteLine(" |_________________|       |_________________|       |_________________|       |_________________|");
            Console.WriteLine("  _________________         _________________         _________________         _________________ ");
            Console.WriteLine(" |     Group  E    |       |     Group  F    |       |     Group G     |       |     Group H     |");
            Console.WriteLine(" |-----------------|       |-----------------|       |-----------------|       |-----------------|");
            Console.WriteLine(" |      Japão      |       |    Marrocos     |       |      Brasil     |       |  Coreia do sul  |");
            Console.WriteLine(" |     Espanha     |       |     Croácia     |       |      Suíça      |       |     Portugal    |");
            Console.WriteLine(" |    Alemanha     |       |     Béligica    |       |      Camarõs    |       |     Uruguai     |");
            Console.WriteLine(" |    Costa Rica   |       |      Canadá     |       |      Sérvia     |       |      Gana       |");
            Console.WriteLine(" |_________________|       |_________________|       |_________________|       |_________________|");
            Console.ReadLine();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo A:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     1 Rodada: Qatar vs Senegal");

            // Cria um novo gerador de números aleatórios
            Random random = new Random();

            // Armazena os gols de cada equipe
            int gqatar = 0;
            int gsenegal = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber = random.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber < 30)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gqatar++;
                }
                else if (randomNumber < 70)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gsenegal++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols
            if (gqatar > gsenegal)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     A equipa Qatar Venceu");
            
               
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("     Qatar: " + gqatar + " - " + gsenegal + " :Senegal");
                
            }
            else if (gqatar < gsenegal)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     A equipa Senegal Venceu");
               
  
                Console.ForegroundColor = ConsoleColor.Magenta;

                Console.WriteLine("     Qatar: " + gqatar + " - " + gsenegal + " :Senegal");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("     O jogo empatou!");
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("     Qatar: " + gqatar + " - " + gsenegal + " :Senegal");
            }

            Console.ForegroundColor = ConsoleColor.White;






            Console.WriteLine("\n\n     2 Rodada: Equador vs Holanda");
            Random random1 = new Random();

            // Armazena os gols de cada equipe
            int gequador = 0;
            int gholanda = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1 = random1.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1 < 30)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gequador++;
                }
                else if (randomNumber1 < 70)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gholanda++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols
            if (gequador > gholanda)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     A equipa Equador Venceu");


                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("     Equador: " + gequador + " - " + gholanda + " :Holanda");

            }
            else if (gequador < gholanda)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     A equipa Holanda Venceu");


                Console.ForegroundColor = ConsoleColor.DarkCyan;

                Console.WriteLine("     Equador: " + gequador + " - " + gholanda + " :Holanda");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("     O jogo empatou!");
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("     Equador: " + gequador + " - " + gholanda + " :Holanda");
            }

            Console.ForegroundColor = ConsoleColor.White;

            




            Console.WriteLine("\n\n     3 Rodada: Qatar vs Holanda");

            Random random3 = new Random();

            // Armazena os gols de cada equipe
            int ggqatar = 0;
            int ggholanda = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber3 = random3.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber3 < 30)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggqatar++;
                }
                else if (randomNumber3 < 70)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggholanda++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Qatar: " + ggqatar + " - " + ggholanda + " :Holanda");
            if (ggqatar > ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Qatar venceu!\n");
            }
            else if (ggqatar == ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggqatar < ggholanda)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Holanda venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     4 Rodada: Equador vs Senegal");


            Random random4 = new Random();

            // Armazena os gols de cada equipe
            int ggequador = 0;
            int ggsenegal = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber4 = random4.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber4 < 20)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggequador++;
                }
                else if (randomNumber4 < 80)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggsenegal++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Equador: " + ggequador + " - " + ggsenegal + " :Senegal");
            if (ggequador > ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Equador venceu!\n");
            }
            else if (ggequador == ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggequador < ggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     5 Rodada: Holanda vs Senegal");

            Random random5 = new Random();

            // Armazena os gols de cada equipe
            int gggholanda = 0;
            int gggsenegal = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber5 = random5.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber5 < 90)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gggholanda++;
                }
                else if (randomNumber5 < 10)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gggsenegal++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Holanda: " + gggholanda + " - " + gggsenegal + " :Senegal");
            if (gggholanda > gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Holanda venceu!\n");
            }
            else if (gggholanda == gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gggholanda < gggsenegal)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Senegal venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     6 Rodada: Qatar vs Equador");

            Random random6 = new Random();

            // Armazena os gols de cada equipe
            int gggqatar = 0;
            int gggequador = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber6 = random6.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber6 < 40)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gggqatar++;
                }
                else if (randomNumber6 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gggequador++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Qatar: " + gggqatar + " - " + gggequador + " :Equador");
            if (gggqatar > gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Qatar venceu!\n");
            }
            else if (gggqatar == gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gggqatar < gggequador)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     Equador venceu!\n\n\n");

            }


            Console.ForegroundColor = ConsoleColor.White;

            int gQa = gggqatar + ggqatar + gqatar;
            int gEQ = gequador + gggequador + ggequador;
            int gSe = gsenegal + gggsenegal + ggsenegal;
            int gHo = gholanda + ggholanda + gggholanda;

            int vQa = 0;
            int vEQ = 0;
            int vHo = 0;
            int vSe = 0;

            int eQa = 0;
            int eEQ = 0;
            int eHo = 0;
            int eSe = 0;

            int dQa = 0;
            int dEQ = 0;
            int dHo = 0;
            int dSe = 0;

            int pQa = 0;
            int pEq = 0;
            int pHo = 0;
            int pSe = 0;

            if (gqatar > gsenegal)
            {
                vQa++;
                dSe++;

            }
            else if (gqatar == gsenegal)
            {
                eQa++;
                eSe++;
            }
            else if (gqatar < gsenegal)
            {
                vSe++;
                dQa++;
            }
            /*-------------------------------------*/
            if (gequador > gholanda)
            {
                vEQ++;
                dHo++;
            }
            else if (gequador == gholanda)
            {
                eEQ++;
                eHo++;

            }
            else if (gequador < gholanda)
            {
                vHo++;
                dEQ++;
            }
            /*-------------------------------------*/
            if (ggqatar > ggholanda)
            {
                vQa++;
                dHo++;
            }
            else if (ggqatar == ggholanda)
            {
                eQa++;
                eHo++;
            }
            else if (ggqatar < ggholanda)
            {
                vHo++;
                dQa++;

            }
            /*-------------------------------------*/
            if (gggholanda > gggsenegal)
            {
                vHo++;
                dSe++;
            }
            else if (gggholanda == gggsenegal)
            {
                eHo++;
                eSe++;
            }
            else if (gggholanda < gggsenegal)
            {
                vSe++;
                dHo++;

            }
            /*-------------------------------------*/
            if (ggequador > ggsenegal)
            {
                vEQ++;
                dSe++;

            }
            else if (ggequador == ggsenegal)
            {
                eEQ++;
                eSe++;
            }
            else if (ggequador < ggsenegal)
            {
                vSe++;
                dEQ++;
            }
            /*-------------------------------------*/
            if (gggqatar > gggequador)
            {
                vQa++;
                dEQ++;
            }
            else if (gggqatar == gggequador)
            {
                eEQ++;
                eQa++;
            }
            else if (gggqatar < gggequador)
            {
                vEQ++;
                dQa++;
            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (gqatar > gsenegal)
            {
                pQa += 3;
            }
            else if (gqatar == gsenegal)
            {
                pQa++;
                pSe++;
            }
            else if (gqatar < gsenegal)
            {
                pSe += 3;
            }
            /*-------------------------------------*/
            if (gequador > gholanda)
            {
                pEq += 3;
            }
            else if (gequador == gholanda)
            {
                pEq++;
                pHo++;

            }
            else if (gequador < gholanda)
            {
                pHo += 3;
            }
            /*-------------------------------------*/
            if (ggqatar > ggholanda)
            {
                pQa += 3;
            }
            else if (ggqatar == ggholanda)
            {
                pQa++;
                pHo++;
            }
            else if (ggqatar < ggholanda)
            {
                pHo += 3;

            }
            /*-------------------------------------*/
            if (gggholanda > gggsenegal)
            {
                pHo += 3;
            }
            else if (gggholanda == gggsenegal)
            {
                pHo++;
                pSe++;
            }
            else if (gggholanda < gggsenegal)
            {
                pSe += 3;

            }
            /*-------------------------------------*/
            if (ggequador > ggsenegal)
            {
                pEq += 3;
            }
            else if (ggequador == ggsenegal)
            {
                pEq++;
                pSe++;
            }
            else if (ggequador < ggsenegal)
            {
                pSe += 3;
            }
            /*-------------------------------------*/
            if (gggqatar > gggequador)
            {
                pQa += 3;
            }
            else if (gggqatar == gggequador)
            {
                pEq++;
                pQa++;
            }
            else if (gggqatar < gggequador)
            {
                pEq += 3;
            }

            // Cria um array com os pontos de cada equipa
            int[] points = new int[] { pQa, pEq, pSe, pHo };

            // Ordena o array em ordem crescente
            Array.Sort(points, (a, b) => b.CompareTo(a));

            // Verifica se a equipa em segundo lugar empatou com a terceira
            if (points[1] == points[2])
            {
                // Gera um número aleatório entre 0 e 1
                Random rnd2323 = new Random();
                double randomNumber2 = rnd2323.NextDouble();

                // Se o número gerado for menor que 0,5, a equipa em segundo lugar fica em primeiro lugar
                // Caso contrário, a equipa em terceiro lugar fica em segundo lugar
                if (randomNumber2 < 0.5)
                {
                    int temp = points[1];
                    points[0] = points[1];
                    points[1] = temp;
                }
                else
                {
                    int temp = points[2];
                    points[2] = points[1];
                    points[1] = temp;
                }
            }
            
            // Imprime os pontos das equipas em ordem crescente
            Console.WriteLine("\n\n     Pontos das Equipas Decrescente:\n");
            foreach (int point in points)
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("     "+point+"\n");
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-------------------------------------\n\n");
            Console.WriteLine("   Quem passou ou não passou:\n");

            if (pQa == points[0])
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     Qatar Passou em Primeiro\n");
            }
            else if (pQa == points[1])
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("     Qatar Passou em Segundo\n");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("     Qatar não passou\n");
            }

            if (pSe == points[0])
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     Senegal Passou em Primeiro\n");
            }
            else if (pSe == points[1])
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("     Senegal Passou em Segundo\n");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("     Senegal não passou\n");
            }
            if (pEq == points[0])
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     Equador Passou em Primeiro\n");
            }
            else if (pEq == points[1])
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("     Equador Passou em Segundo\n");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("     Equador não passou\n");
            }
            if (pHo == points[0])
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("     Holanda Passou em Primeiro\n");
            }
            else if (pHo == points[1])
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine("     Holanda Passou em Segundo\n");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("     Holanda não passou\n");
            }

                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n\n\n\n _____________________________________________________");
                Console.WriteLine(" |      Group  A      |  V  |  E  |  D  |  GM | Pts | ");
                Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
                Console.WriteLine(" |      "+Qatar+"         |  " + vQa + "  |  " + eQa + "  |  " + dQa + "  |  " + gQa + "  |  " + pQa + "  | ");
                Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
                Console.WriteLine(" |     "+Equador+"        |  " + vEQ + "  |  " + eEQ + "  |  " + dEQ + "  |  " + gEQ + "  |  " + pEq + "  | ");
                Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
                Console.WriteLine(" |     "+Senegal+"        |  " + vSe + "  |  " + eSe + "  |  " + dSe + "  |  " + gSe + "  |  " + pSe + "  | ");
                Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
                Console.WriteLine(" |     "+Holanda+"        |  " + vHo + "  |  " + eHo + "  |  " + dHo + "  |  " + gHo + "  |  " + pHo + "  | ");
                Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
                Console.ReadLine();
                Console.Clear();

                

            
     







            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: B");
            Console.ForegroundColor = ConsoleColor.White;





            Console.WriteLine("\n\n     1 Rodada: Inglaterra vs Estados Unidos");

            Random random7 = new Random();

            // Armazena os gols de cada equipe
            int inglaterra = 0;
            int estadosunidos = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber7 = random7.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber7 < 75)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    inglaterra++;
                }
                else if (randomNumber7 < 55)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    estadosunidos++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Inglaterra: " + inglaterra + " - " + estadosunidos + " :Estados Unidos");
            if (inglaterra > estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (inglaterra == estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (inglaterra < estadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     2 Jogo: Irã vs País de Gales");

            Random random8 = new Random();

            // Armazena os gols de cada equipe
            int ira = 0;
            int paisgales = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber8 = random8.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber8 < 35)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ira++;
                }
                else if (randomNumber8 < 75)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    paisgales++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Irã: " + ira + " - " + paisgales + " :País de Gales");
            if (ira > paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Irã venceu!\n");
            }
            else if (ira == paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ira < paisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     3 Jogo: Estados Unidos vs Irã");

            Random random9 = new Random();

            // Armazena os gols de cada equipe
            int gira = 0;
            int gestadosunidos = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber9 = random9.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber9 < 25)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gira++;
                }
                else if (randomNumber9 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gestadosunidos++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Irã: " + gira + " - " + gestadosunidos + " :Estados Unidos");
            if (gira > gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Irã venceu!\n");
            }
            else if (gira == gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gira < gestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     4 Jogo: Inglaterra vs País de Gales");

            Random random10 = new Random();

            // Armazena os gols de cada equipe
            int ginglaterra = 0;
            int gpaisgales = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10 = random10.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ginglaterra++;
                }
                else if (randomNumber10 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gpaisgales++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Inglaterra: " + ginglaterra + " - " + gpaisgales + " :País de Gales");
            if (ginglaterra > gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (ginglaterra == gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ginglaterra < gpaisgales)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     5 Jogo: Estados Unidos vs País de Gales");

            Random rnd22 = new Random();

            int ggpaisdegales = rnd22.Next(0, 3);

            Random rnd23 = new Random();

            int ggestadosunidos = rnd23.Next(0, 3);


            Console.WriteLine("     País de Gales: " + ggpaisdegales + " - " + ggestadosunidos + " :Estados Unidos");
            if (ggpaisdegales > ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     País de Gales venceu!\n");
            }
            else if (ggpaisdegales == ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggpaisdegales < ggestadosunidos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Estados Unidos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     6 Jogo: Inglaterra vs País de Gales");

            Random random11 = new Random();

            // Armazena os gols de cada equipe
            int ggginglaterra = 0;
            int gggira = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber11 = random11.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber11 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggginglaterra++;
                }
                else if (randomNumber11 < 30)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gggira++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Inglaterra: " + ggginglaterra + " - " + gggira + " :Irã");
            if (ggginglaterra > gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Inglaterra venceu!\n");
            }
            else if (ggginglaterra == gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggginglaterra < gggira)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     irã venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;



            int gIg = ginglaterra + ggginglaterra + inglaterra;
            int gIr = gira + gggira + ira;
            int gPg = ggpaisdegales + gpaisgales + paisgales;
            int gEu = ggestadosunidos + gestadosunidos + estadosunidos;

            int vIg = 0;
            int vIr = 0;
            int vPg = 0;
            int vEu = 0;

            int eIg = 0;
            int eIr = 0;
            int ePg = 0;
            int eEu = 0;

            int dIg = 0;
            int dIr = 0;
            int dPg = 0;
            int dEu = 0;

            int pIg = 0;
            int pIr = 0;
            int pPg = 0;
            int pEu = 0;

            if (inglaterra > estadosunidos)
            {
                vIg++;
                dEu++;
            }
            else if (inglaterra == estadosunidos)
            {
                eIg++;
                eEu++;

            }
            else if (inglaterra < estadosunidos)
            {
                vEu++;
                dIg++;

            }
            /*-------------------------------------*/
            if (ira > paisgales)
            {
                vIr++;
                dPg++;

            }
            else if (ira == paisgales)
            {
                eIr++;
                ePg++;
            }
            else if (ira < paisgales)
            {
                vPg++;
                dIr++;

            }
            /*-------------------------------------*/
            if (gira > gestadosunidos)
            {
                vIr++;
                dEu++;

            }
            else if (gira == gestadosunidos)
            {
                eIr++;
                eEu++;

            }
            else if (gira < gestadosunidos)
            {
                vEu++;
                dIr++;

            }
            /*-------------------------------------*/
            if (ginglaterra > gpaisgales)
            {
                vIg++;
                dPg++;
            }
            else if (ginglaterra == gpaisgales)
            {
                eIg++;
                ePg++;

            }
            else if (ginglaterra < gpaisgales)
            {
                vPg++;
                dIg++;

            }

            /*-------------------------------------*/
            if (ggpaisdegales > ggestadosunidos)
            {
                vPg++;
                dEu++;
            }
            else if (ggpaisdegales == ggestadosunidos)
            {
                ePg++;
                eEu++;

            }
            else if (ggpaisdegales < ggestadosunidos)
            {
                vEu++;
                dPg++;

            }
            /*-------------------------------------*/
            if (ggginglaterra > gggira)
            {
                vIg++;
                dIr++;

            }
            else if (ggginglaterra == gggira)
            {
                eIg++;
                eIr++;

            }
            else if (ggginglaterra < gggira)
            {
                vIr++;
                dIg++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (inglaterra > estadosunidos)
            {
                pIg += 3;
            }
            else if (inglaterra == estadosunidos)
            {
                pIg++;
                pEu++;

            }
            else if (inglaterra < estadosunidos)
            {

                pEu += 3;
            }
            /*-------------------------------------*/
            if (ira > paisgales)
            {
                pIr += 3;

            }
            else if (ira == paisgales)
            {
                pIr++;
                pPg++;
            }
            else if (ira < paisgales)
            {
                pPg += 3;

            }
            /*-------------------------------------*/
            if (gira > gestadosunidos)
            {
                pIr += 3;

            }
            else if (gira == gestadosunidos)
            {
                pIr++;
                pEu++;

            }
            else if (gira < gestadosunidos)
            {
                pEu += 3;

            }
            /*-------------------------------------*/
            if (ginglaterra > gpaisgales)
            {
                pIg += 3;
            }
            else if (ginglaterra == gpaisgales)
            {
                pIg++;
                pPg++;

            }
            else if (ginglaterra < gpaisgales)
            {
                pPg += 3;

            }
            /*-------------------------------------*/
            if (ggpaisdegales > ggestadosunidos)
            {
                pPg += 3;
            }
            else if (ggpaisdegales == ggestadosunidos)
            {
                pPg++;
                pEu++;

            }
            else if (ggpaisdegales < ggestadosunidos)
            {
                pEu += 3;

            }
            /*-------------------------------------*/
            if (ggginglaterra > gggira)
            {
                pIg += 3;

            }
            else if (ggginglaterra == gggira)
            {
                pIg++;
                pIr++;

            }
            else if (ggginglaterra < gggira)
            {
                pIr += 3;

            }



            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  B      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |    Inglaterra      |  " + vIg + "  |  " + eIg + "  |  " + dIg + "  |  " + gIg + "  |  " + pIg + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |   Estados Unidos   |  " + vEu + "  |  " + eEu + "  |  " + dEu + "  |  " + gEu + "  |  " + pEu + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Irã          |  " + vIr + "  |  " + eIr + "  |  " + dIr + "  |  " + gIr + "  |  " + pIr + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |   País de Gales    |  " + vPg + "  |  " + ePg + "  |  " + dPg + "  |  " + gPg + "  |  " + pPg + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();




            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: C");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Argentina vs Arábia Saudita ");

            Random random12 = new Random();

            // Armazena os gols de cada equipe
            int argentina = 0;
            int arabia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber12 = random12.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber12 < 90)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    argentina++;
                }
                else if (randomNumber12 < 20)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    arabia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Argentina: " + argentina + " - " + arabia + " :Arábia Saudita");
            if (argentina > arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (argentina == arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (argentina < arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     2 Rodada: Mexico vs Polónia ");

            Random random13 = new Random();

            // Armazena os gols de cada equipe
            int mexico = 0;
            int polonia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber13 = random13.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber13 < 90)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    mexico++;
                }
                else if (randomNumber13 < 20)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    polonia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Mexico: " + mexico + " - " + polonia + " :Polónia");
            if (mexico > polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Mexico venceu!\n");
            }
            else if (mexico == polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (mexico < polonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Polónia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     3 Rodada: Polónia vs Arábia Saudita ");

            Random random14 = new Random();

            // Armazena os gols de cada equipe
            int gpolonia = 0;
            int garabia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber14 = random14.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber14 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gpolonia++;
                }
                else if (randomNumber14 < 40)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    garabia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Polónia: " + gpolonia + " - " + garabia + " :Arábia Saudita");
            if (gpolonia > garabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Polónia venceu!\n");
            }
            else if (gpolonia == arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gpolonia < arabia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     4 Rodada: Argentina vs Mexico ");

            Random random15 = new Random();

            // Armazena os gols de cada equipe
            int gargentina = 0;
            int gmexico = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber15 = random15.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber15 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gargentina++;
                }
                else if (randomNumber15 < 40)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gmexico++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Argentina: " + gargentina + " - " + gmexico + " :Mexico");
            if (gargentina > gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (gargentina == gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gargentina < gmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Mexico venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     5 Rodada: Argentina vs Polónia ");

            Random random16 = new Random();

            // Armazena os gols de cada equipe
            int ggargentina = 0;
            int ggpolonia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber16 = random16.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber16 < 75)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggargentina++;
                }
                else if (randomNumber16 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggpolonia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Argentina: " + ggargentina + " - " + ggpolonia + " :polónia");
            if (ggargentina > ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Argentina venceu!\n");
            }
            else if (ggargentina == ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggargentina < ggpolonia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Plónia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Arábia Saudita vs Mexico ");

            Random random17 = new Random();

            // Armazena os gols de cada equipe
            int ggarabia = 0;
            int ggmexico = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber17 = random17.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber17 < 30)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggarabia++;
                }
                else if (randomNumber17 < 70)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggmexico++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Arábia Saudita: " + ggarabia + " - " + ggmexico + " :Mexico");
            if (ggarabia > ggmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Arábia Saudita venceu!\n");
            }
            else if (ggarabia == ggmexico)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggarabia < ggmexico)
            {
                Console.Write("Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("Mexico venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;

            int gAr = garabia + ggarabia + arabia;
            int gMe = gmexico + ggmexico + mexico;
            int gPo = gpolonia + ggpolonia + polonia;
            int gAg = gargentina + ggargentina + argentina;

            int vAr = 0;
            int vMe = 0;
            int vPo = 0;
            int vAg = 0;

            int eAr = 0;
            int eMe = 0;
            int ePo = 0;
            int eAg = 0;

            int dAr = 0;
            int dMe = 0;
            int dPo = 0;
            int dAg = 0;

            int pAr = 0;
            int pMe = 0;
            int pPo = 0;
            int pAg = 0;

            if (argentina > arabia)
            {
                vAg++;
                dAr++;
            }
            else if (argentina == arabia)
            {
                eAg++;
                eAr++;

            }
            else if (argentina < arabia)
            {
                vAr++;
                dAg++;

            }
            /*-------------------------------------*/
            if (mexico > polonia)
            {
                vMe++;
                dPo++;
            }
            else if (mexico == polonia)
            {
                eMe++;
                ePo++;
            }
            else if (mexico < polonia)
            {
                vPo++;
                dMe++;
            }
            /*-------------------------------------*/
            if (gpolonia > garabia)
            {
                vPo++;
                dAr++;
            }
            else if (gpolonia == arabia)
            {
                ePo++;
                eAr++;
            }
            else if (gpolonia < arabia)
            {
                vAr++;
                dPo++;

            }

            /*-------------------------------------*/
            if (gargentina > gmexico)
            {
                vAg++;
                dMe++;
            }
            else if (gargentina == gmexico)
            {
                eAg++;
                eMe++;
            }
            else if (gargentina < gmexico)
            {
                vMe++;
                dAr++;
            }
            /*-------------------------------------*/
            if (ggargentina > ggpolonia)
            {
                vAg++;
                dPo++;
            }
            else if (ggargentina == ggpolonia)
            {
                eAg++;
                ePo++;

            }
            else if (ggargentina < ggpolonia)
            {
                vPo++;
                dAg++;


            }
            /*-------------------------------------*/
            if (ggarabia > ggmexico)
            {
                vAr++;
                dMe++;
            }
            else if (ggarabia == ggmexico)
            {
                eMe++;
                eAr++;

            }
            else if (ggarabia < ggmexico)
            {
                vMe++;
                dAr++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (argentina > arabia)
            {
                pAg += 3;
            }
            else if (argentina == arabia)
            {
                pAg++;
                pAr++;

            }
            else if (argentina < arabia)
            {

                pAr += 3;

            }
            /*-------------------------------------*/
            if (mexico > polonia)
            {
                pMe += 3;
            }
            else if (mexico == polonia)
            {
                pMe++;
                pPo++;
            }
            else if (mexico < polonia)
            {
                pPo += 3;
            }
            /*-------------------------------------*/
            if (gpolonia > garabia)
            {
                pPo += 3;
            }
            else if (gpolonia == arabia)
            {
                pPo++;
                pAr++;
            }
            else if (gpolonia < arabia)
            {
                pAr += 3;

            }
            /*-------------------------------------*/
            if (gargentina > gmexico)
            {
                pAg += 3;
            }
            else if (gargentina == gmexico)
            {
                pAg++;
                pMe++;
            }
            else if (gargentina < gmexico)
            {
                pMe += 3;
            }
            /*-------------------------------------*/
            if (ggargentina > ggpolonia)
            {
                pAg += 3;

            }
            else if (ggargentina == ggpolonia)
            {
                pAg++;
                pPo++;

            }
            else if (ggargentina < ggpolonia)
            {
                pPo += 3;

            }
            /*-------------------------------------*/
            if (ggarabia > ggmexico)
            {
                pAr += 3;
            }
            else if (ggarabia == ggmexico)
            {
                pMe++;
                pAr++;

            }
            else if (ggarabia < ggmexico)
            {
                pMe += 3;

            }



            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  C      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Mexico       |  " + vMe + "  |  " + eMe + "  |  " + dMe + "  |  " + gMe + "  |  " + pMe + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Polonia       |  " + vPo + "  |  " + ePo + "  |  " + dPo + "  |  " + gPo + "  |  " + pPo + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |     Argentina      |  " + vAg + "  |  " + eAg + "  |  " + dAg + "  |  " + gAg + "  |  " + pAg + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |   Arabia Saudita   |  " + vAr + "  |  " + eAr + "  |  " + dAr + "  |  " + gAr + "  |  " + pAr + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();


            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: D");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Dinamarca vs Tunísia ");

            Random random18 = new Random();

            // Armazena os gols de cada equipe
            int dinamarca = 0;
            int tunisia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber18 = random18.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber18 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    dinamarca++;
                }
                else if (randomNumber18 < 45)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    tunisia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols

            Console.WriteLine("     Dinamarca: " + dinamarca + " - " + tunisia + " :Tunísia");
            if (dinamarca > tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!\n");
            }
            else if (dinamarca == tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (dinamarca < tunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     2 Rodada: Austrália vs França ");

            Random random19 = new Random();

            // Armazena os gols de cada equipe
            int australia = 0;
            int franca = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber19 = random19.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber19 < 40)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    australia++;
                }
                else if (randomNumber19 < 75)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    franca++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Austrália: " + australia + " - " + franca + " :França");
            if (australia > franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (australia == franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (australia < franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     3 Rodada: Austrália vs Tunísia ");

            Random random20 = new Random();

            // Armazena os gols de cada equipe
            int gaustralia = 0;
            int gtunisia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber20 = random20.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber20 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gaustralia++;
                }
                else if (randomNumber20 < 45)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gtunisia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Austrália: " + gaustralia + " - " + gtunisia + " :Tunísia");
            if (gaustralia > gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (gaustralia == gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gaustralia < gtunisia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     4 Rodada: Dinamarca vs França ");

            Random random21 = new Random();

            // Armazena os gols de cada equipe
            int gdinamarca = 0;
            int gfranca = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber21 = random21.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber21 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gdinamarca++;
                }
                else if (randomNumber21 < 85)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gfranca++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Dinamarca: " + gdinamarca + " - " + gfranca + " :França");
            if (gdinamarca > gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!\n");
            }
            else if (gdinamarca == gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gdinamarca < gfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     5 Rodada: Tunísia vs França ");

            Random random22 = new Random();

            // Armazena os gols de cada equipe
            int ggtunisia = 0;
            int ggfranca = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber22 = random22.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber22 < 40)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggtunisia++;
                }
                else if (randomNumber22 < 80)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggfranca++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Tunísia: " + ggtunisia + " - " + ggfranca + " :França");
            if (ggtunisia > ggfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Tunísia venceu!\n");
            }
            else if (ggtunisia == ggfranca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggtunisia < franca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     França venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Austrália vs Dinamarca ");

            Random random24 = new Random();

            // Armazena os gols de cada equipe
            int ggaustralia = 0;
            int ggdinamarca = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber24 = random24.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber24 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggaustralia++;
                }
                else if (randomNumber24 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggdinamarca++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Austrália: " + ggaustralia + " - " + ggdinamarca + " :Dinamarca");
            if (ggaustralia > ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Austrália venceu!\n");
            }
            else if (ggaustralia == ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggaustralia < ggdinamarca)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Dinamarca venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;

            int gDi = dinamarca + gdinamarca + ggdinamarca;
            int gAu = australia + gaustralia + ggaustralia;
            int gTu = tunisia + gtunisia + ggtunisia;
            int gFr = franca + gfranca + ggfranca;

            int vDi = 0;
            int vAu = 0;
            int vTu = 0;
            int vFr = 0;

            int eDi = 0;
            int eAu = 0;
            int eTu = 0;
            int eFr = 0;

            int dDi = 0;
            int dAu = 0;
            int dTu = 0;
            int dFr = 0;

            int pDi = 0;
            int pAu = 0;
            int pTu = 0;
            int pFr = 0;

            if (dinamarca > tunisia)
            {
                vDi++;
                dTu++;
            }
            else if (dinamarca == tunisia)
            {
                eDi++;
                eTu++;

            }
            else if (dinamarca < tunisia)
            {
                vTu++;
                dDi++;

            }
            /*-------------------------------------*/
            if (australia > franca)
            {
                vAu++;
                dFr++;
            }
            else if (australia == franca)
            {
                eAu++;
                eFr++;

            }
            else if (australia < franca)
            {
                vFr++;
                dAu++;
            }
            /*-------------------------------------*/
            if (gaustralia > gtunisia)
            {
                vAu++;
                dTu++;
            }
            else if (gaustralia == gtunisia)
            {
                eAu++;
                eTu++;

            }
            else if (gaustralia < gtunisia)
            {
                vTu++;
                dAu++;

            }

            /*-------------------------------------*/
            if (gdinamarca > gfranca)
            {
                vDi++;
                dFr++;
            }
            else if (gdinamarca == gfranca)
            {
                eDi++;
                eFr++;

            }
            else if (gdinamarca < gfranca)
            {
                vFr++;
                dDi++;

            }
            /*-------------------------------------*/
            if (ggtunisia > ggfranca)
            {
                vTu++;
                dFr++;
            }
            else if (ggtunisia == ggfranca)
            {
                eTu++;
                eFr++;

            }
            else if (ggtunisia < franca)
            {
                vFr++;
                dTu++;

            }
            /*-------------------------------------*/
            if (ggaustralia > ggdinamarca)
            {
                vAu++;
                dDi++;
            }
            else if (ggaustralia == ggdinamarca)
            {
                eAu++;
                eDi++;

            }
            else if (ggaustralia < ggdinamarca)
            {
                vDi++;
                dAu++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (dinamarca > tunisia)
            {
                pDi += 3;
            }
            else if (dinamarca == tunisia)
            {
                pDi++;
                pTu++;

            }
            else if (dinamarca < tunisia)
            {
                pTu += 3;

            }
            /*-------------------------------------*/
            if (australia > franca)
            {
                pAu += 3;
            }
            else if (australia == franca)
            {
                pAu++;
                pFr++;

            }
            else if (australia < franca)
            {
                pFr += 3;
            }
            /*-------------------------------------*/
            if (gaustralia > gtunisia)
            {
                pAu += 3;
            }
            else if (gaustralia == gtunisia)
            {
                pAu++;
                pTu++;

            }
            else if (gaustralia < gtunisia)
            {
                pTu += 3;

            }
            /*-------------------------------------*/
            if (gdinamarca > gfranca)
            {
                pDi += 3;
            }
            else if (gdinamarca == gfranca)
            {
                pDi++;
                pFr++;

            }
            else if (gdinamarca < gfranca)
            {
                pFr += 3;

            }
            /*-------------------------------------*/
            if (ggtunisia > ggfranca)
            {
                pTu += 3;
            }
            else if (ggtunisia == ggfranca)
            {
                pTu++;
                pFr++;

            }
            else if (ggtunisia < franca)
            {
                pFr += 3;

            }
            /*-------------------------------------*/
            if (ggaustralia > ggdinamarca)
            {
                pAu += 3;
            }
            else if (ggaustralia == ggdinamarca)
            {
                pAu++;
                pDi++;

            }
            else if (ggaustralia < ggdinamarca)
            {
                pDi += 3;

            }



            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  D      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Dinamarca     |  " + vDi + "  |  " + eDi + "  |  " + dDi + "  |  " + gDi + "  |  " + pDi + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       França       |  " + vFr + "  |  " + eFr + "  |  " + dFr + "  |  " + gFr + "  |  " + pFr + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Australia     |  " + vAu + "  |  " + eAu + "  |  " + dAu + "  |  " + gAu + "  |  " + pAu + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Tunisia       |  " + vTu + "  |  " + eTu + "  |  " + dTu + "  |  " + gTu + "  |  " + pTu + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();





            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: E");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Alemanha vs Japão ");

            Random random25 = new Random();

            // Armazena os gols de cada equipe
            int alemanha = 0;
            int japao = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber25 = random25.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber25 < 75)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    alemanha++;
                }
                else if (randomNumber25 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    japao++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Alemanha : " + alemanha + " - " + japao + " :Japão");
            if (alemanha > japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (alemanha == japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (alemanha < japao)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     2 Rodada: Espanha vs Costa Rica ");

            Random random26 = new Random();

            // Armazena os gols de cada equipe
            int espanha = 0;
            int costarica = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber26 = random26.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber26 < 85)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    espanha++;
                }
                else if (randomNumber26 < 35)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    costarica++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Espanha : " + espanha + " - " + costarica + " :Costa Rica");
            if (espanha > costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!\n");
            }
            else if (espanha == costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (espanha < costarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     3 Rodada: Japão vs Costa Rica ");

            Random random27 = new Random();

            // Armazena os gols de cada equipe
            int gjapao = 0;
            int gcostarica = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber27 = random27.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber27 < 55)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gjapao++;
                }
                else if (randomNumber27 < 40)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gcostarica++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Japão : " + gjapao + " - " + gcostarica + " :Costa Rica");
            if (gjapao > gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");
            }
            else if (gjapao == gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gjapao < gcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     4 Rodada: Alemanha vs Espanha ");

            Random random28 = new Random();

            // Armazena os gols de cada equipe
            int galemanha = 0;
            int gespanha = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber28 = random28.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber28 < 55)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    galemanha++;
                }
                else if (randomNumber28 < 75)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gespanha++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Alemanha: " + galemanha + " - " + gespanha + " :Espanha");
            if (galemanha > gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (galemanha == gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (galemanha < gespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     5 Rodada: Alemanha vs Costa Rica ");

            Random random29 = new Random();

            // Armazena os gols de cada equipe
            int ggalemanha = 0;
            int ggcostarica = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber29 = random29.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber29 < 75)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggalemanha++;
                }
                else if (randomNumber29 < 30)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggcostarica++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Alemaha: " + ggalemanha + " - " + ggcostarica + " :Costa Rica");
            if (ggalemanha > ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Alemanha venceu!\n");
            }
            else if (ggalemanha == ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggalemanha < ggcostarica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Costa Rica venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     6 Rodada: Japão vs Espanha ");

            Random random30 = new Random();

            // Armazena os gols de cada equipe
            int ggjapao = 0;
            int ggespanha = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber30 = random30.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber30 < 35)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggjapao++;
                }
                else if (randomNumber30 < 65)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggespanha++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Japão : " + ggjapao + " - " + ggespanha + " :Espanha");
            if (ggjapao > ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Japão venceu!\n");
            }
            else if (ggjapao == ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggjapao < ggespanha)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Espanha venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            int gjap = japao + gjapao + ggjapao;
            int ges = espanha + gespanha + ggespanha;
            int gale = alemanha + galemanha + ggalemanha;
            int gcos = costarica + gcostarica + ggcostarica;

            int vjap = 0;
            int ves = 0;
            int vale = 0;
            int vcos = 0;

            int ejap = 0;
            int ees = 0;
            int eale = 0;
            int ecos = 0;

            int djap = 0;
            int des = 0;
            int dale = 0;
            int dcos = 0;

            int pjap = 0;
            int pes = 0;
            int pale = 0;
            int pcos = 0;

            if (alemanha > japao)
            {
                vale++;
                djap++;
            }
            else if (alemanha == japao)
            {
                eale++;
                ejap++;

            }
            else if (alemanha < japao)
            {
                vjap++;
                dale++;

            }
            /*-------------------------------------*/
            if (espanha > costarica)
            {
                ves++;
                dcos++;
            }
            else if (espanha == costarica)
            {
                ees++;
                ecos++;

            }
            else if (espanha < costarica)
            {
                vcos++;
                des++;

            }
            /*-------------------------------------*/
            if (gjapao > gcostarica)
            {
                vjap++;
                dcos++;
            }
            else if (gjapao == gcostarica)
            {
                ejap++;
                ecos++;

            }
            else if (gjapao < gcostarica)
            {
                vcos++;
                djap++;

            }
            /*-------------------------------------*/
            if (galemanha > gespanha)
            {
                vale++;
                des++;
            }
            else if (galemanha == gespanha)
            {
                eale++;
                ees++;

            }
            else if (galemanha < gespanha)
            {
                ves++;
                dale++;

            }
            /*-------------------------------------*/
            if (ggalemanha > ggcostarica)
            {
                vale++;
                dcos++;
            }
            else if (ggalemanha == ggcostarica)
            {
                eale++;
                ecos++;

            }
            else if (ggalemanha < ggcostarica)
            {
                vcos++;
                dale++;

            }
            /*-------------------------------------*/
            if (ggjapao > ggespanha)
            {
                vjap++;
                des++;
            }
            else if (ggjapao == ggespanha)
            {
                ejap++;
                ees++;

            }
            else if (ggjapao < ggespanha)
            {
                ves++;
                djap++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (alemanha > japao)
            {
                pale += 3;
            }
            else if (alemanha == japao)
            {
                pale++;
                pjap++;

            }
            else if (alemanha < japao)
            {
                pjap += 3;

            }
            /*-------------------------------------*/
            if (espanha > costarica)
            {
                pes += 3;
            }
            else if (espanha == costarica)
            {
                pes++;
                pcos++;

            }
            else if (espanha < costarica)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (gjapao > gcostarica)
            {
                pjap += 3;
            }
            else if (gjapao == gcostarica)
            {
                pjap++;
                pcos++;

            }
            else if (gjapao < gcostarica)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (galemanha > gespanha)
            {
                pale += 3;
            }
            else if (galemanha == gespanha)
            {
                pale++;
                pes++;

            }
            else if (galemanha < gespanha)
            {
                pes += 3;

            }
            /*-------------------------------------*/
            if (ggalemanha > ggcostarica)
            {
                pale += 3;
            }
            else if (ggalemanha == ggcostarica)
            {
                pale++;
                pcos++;

            }
            else if (ggalemanha < ggcostarica)
            {
                pcos += 3;

            }
            /*-------------------------------------*/
            if (ggjapao > ggespanha)
            {
                pjap += 3;
            }
            else if (ggjapao == ggespanha)
            {
                pjap++;
                pes++;

            }
            else if (ggjapao < ggespanha)
            {
                pes += 3;

            }


            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  E      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Japão        |  " + vjap + "  |  " + ejap + "  |  " + djap + "  |  " + gjap + "  |  " + pjap + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Espanha       |  " + ves + "  |  " + ees + "  |  " + des + "  |  " + ges + "  |  " + pes + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |     Alemanha       |  " + vale + "  |  " + eale + "  |  " + dale + "  |  " + gale + "  |  " + pale + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |    Costa Rica      |  " + vcos + "  |  " + ecos + "  |  " + dcos + "  |  " + gcos + "  |  " + pcos + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: F");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Bélgica vs  Canadá");

            Random random31 = new Random();

            // Armazena os gols de cada equipe
            int belgica = 0;
            int canada = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber31 = random31.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber31 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    belgica++;
                }
                else if (randomNumber31 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    canada++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Bélgica: " + belgica + " - " + canada + " :Canadá");
            if (belgica > canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Belgica venceu!\n");
            }
            else if (belgica == canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (belgica < canada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     2 Rodada: Croácia vs  Marrocos");

            Random random32 = new Random();

            // Armazena os gols de cada equipe
            int croacia = 0;
            int marrocos = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber32 = random32.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber32 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    croacia++;
                }
                else if (randomNumber32 < 30)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    marrocos++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Croácia: " + croacia + " - " + marrocos + " :Marrocos");
            if (croacia > marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (croacia == marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (croacia < marrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croacia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     3 Rodada: Croácia vs  Canadá");

            Random random33 = new Random();

            // Armazena os gols de cada equipe
            int gcroacia = 0;
            int gcanada = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber33 = random33.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber33 < 55)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gcroacia++;
                }
                else if (randomNumber33 < 45)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gcanada++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Croácia: " + gcroacia + " - " + gcanada + " :Canadá");
            if (gcroacia > gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (gcroacia == gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcroacia < gcanada)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     4 Rodada: Bélgica vs Marrocos");

            Random random34 = new Random();

            // Armazena os gols de cada equipe
            int gbelgica = 0;
            int gmarrocos = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber34 = random34.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber34 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gbelgica++;
                }
                else if (randomNumber34 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gmarrocos++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Bélgica: " + gbelgica + " - " + gmarrocos + " :Marrocos");
            if (gbelgica > gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Belgica venceu!\n");
            }
            else if (gbelgica == gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gbelgica < gmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Marrocos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     5 Rodada: Canadá vs Marrocos");

            Random random35 = new Random();

            // Armazena os gols de cada equipe
            int ggcanada = 0;
            int ggmarrocos = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber35 = random35.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber35 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggcanada++;
                }
                else if (randomNumber35 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggmarrocos++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Canadá: " + ggcanada + " - " + ggmarrocos + " :Marrocos");
            if (ggcanada > ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Canadá venceu!\n");
            }
            else if (ggcanada == ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcanada < ggmarrocos)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Marrocos venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     6 Rodada: Croácia vs  Bélgica");

            Random random36 = new Random();

            // Armazena os gols de cada equipe
            int ggcroacia = 0;
            int ggbelgica = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber36 = random36.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber36 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggcroacia++;
                }
                else if (randomNumber36 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggbelgica++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Croácia: " + ggcroacia + " - " + ggbelgica + " :Bélgica");
            if (ggcroacia > ggbelgica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Croácia venceu!\n");
            }
            else if (ggcroacia == ggbelgica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcroacia < ggbelgica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Bélgica venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            int gmar = marrocos + gmarrocos + ggmarrocos;
            int gcro = croacia + gcroacia + ggcroacia;
            int gbel = belgica + gbelgica + ggbelgica;
            int gcan = canada + gcanada + ggcanada;

            int vmar = 0;
            int vcro = 0;
            int vbel = 0;
            int vcan = 0;

            int emar = 0;
            int ecro = 0;
            int ebel = 0;
            int ecan = 0;

            int dmar = 0;
            int dcro = 0;
            int dbel = 0;
            int dcan = 0;

            int pmar = 0;
            int pcro = 0;
            int pbel = 0;
            int pcan = 0;

            if (belgica > canada)
            {
                vbel++;
                dcan++;
            }
            else if (belgica == canada)
            {
                ebel++;
                ecan++;

            }
            else if (belgica < canada)
            {
                vcan++;
                dbel++;

            }
            /*-------------------------------------*/
            if (croacia > marrocos)
            {
                vcro++;
                dmar++;
            }
            else if (croacia == marrocos)
            {
                ecro++;
                emar++;

            }
            else if (croacia < marrocos)
            {
                vmar++;
                dcro++;

            }
            /*-------------------------------------*/
            if (gcroacia > gcanada)
            {
                vcro++;
                dcan++;
            }
            else if (gcroacia == gcanada)
            {
                ecro++;
                ecan++;

            }
            else if (gcroacia < gcanada)
            {
                vcan++;
                dcro++;

            }
            /*-------------------------------------*/
            if (gbelgica > gmarrocos)
            {
                vbel++;
                dmar++;
            }
            else if (gbelgica == gmarrocos)
            {
                ebel++;
                emar++;

            }
            else if (gbelgica < gmarrocos)
            {
                vmar++;
                dbel++;

            }
            /*-------------------------------------*/
            if (ggcanada > ggmarrocos)
            {
                vcan++;
                dmar++;
            }
            else if (ggcanada == ggmarrocos)
            {
                ecan++;
                emar++;
            }
            else if (ggcanada < ggmarrocos)
            {
                vmar++;
                dcan++;

            }
            /*-------------------------------------*/
            if (ggcroacia > ggbelgica)
            {
                vcro++;
                dcan++;
            }
            else if (ggcroacia == ggbelgica)
            {
                ecro++;
                ebel++;

            }
            else if (ggcroacia < ggbelgica)
            {
                vbel++;
                dcro++;

            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (belgica > canada)
            {
                pbel += 3;
            }
            else if (belgica == canada)
            {
                pbel++;
                pcan++;

            }
            else if (belgica < canada)
            {
                pcan += 3;

            }
            /*-------------------------------------*/
            if (croacia > marrocos)
            {
                pcro += 3;
            }
            else if (croacia == marrocos)
            {
                pcro++;
                pmar++;

            }
            else if (croacia < marrocos)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (gcroacia > gcanada)
            {
                pcro += 3;
            }
            else if (gcroacia == gcanada)
            {
                pcro++;
                pcan++;

            }
            else if (gcroacia < gcanada)
            {
                pcan += 3;

            }
            /*-------------------------------------*/
            if (gbelgica > gmarrocos)
            {
                pbel += 3;
            }
            else if (gbelgica == gmarrocos)
            {
                pbel++;
                pmar++;

            }
            else if (gbelgica < gmarrocos)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (ggcanada > ggmarrocos)
            {
                pcan += 3; ;
            }
            else if (ggcanada == ggmarrocos)
            {
                pcan++;
                pmar++;
            }
            else if (ggcanada < ggmarrocos)
            {
                pmar += 3;

            }
            /*-------------------------------------*/
            if (ggcroacia > ggbelgica)
            {
                pcro += 3;
            }
            else if (ggcroacia == ggbelgica)
            {
                pcro++;
                pbel++;

            }
            else if (ggcroacia < ggbelgica)
            {
                pbel += 3;

            }


            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  F      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Marrocos     |  " + vmar + "  |  " + emar + "  |  " + dmar + "  |  " + gmar + "  |  " + pmar + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |        Croácia     |  " + vcro + "  |  " + ecro + "  |  " + dcro + "  |  " + gcro + "  |  " + pcro + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Bélgica      |  " + vbel + "  |  " + ebel + "  |  " + dbel + "  |  " + gbel + "  |  " + pbel + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Canadá       |  " + vcan + "  |  " + ecan + "  |  " + dcan + "  |  " + gcan + "  |  " + pcan + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: G");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     1 Rodada: Brasil vs Sérvia");

            Random random37 = new Random();

            // Armazena os gols de cada equipe
            int brasil = 0;
            int servia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber37 = random37.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber37 < 85)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    brasil++;
                }
                else if (randomNumber37 < 75)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    servia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Brasil: " + brasil + " - " + servia + " :sérvia");
            if (brasil > servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Brasil venceu!\n");
            }
            else if (brasil == servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (brasil < servia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.WriteLine("\n\n     2 Rodada: Suíça vs Camarões");

            Random random38 = new Random();
            // Armazena os gols de cada equipe
            int suica = 0;
            int camaroes = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber38 = random38.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber38 < 75)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    suica++;
                }
                else if (randomNumber38 < 30)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    camaroes++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Suíça: " + suica + " - " + camaroes + " :servia");
            if (suica > camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");
            }
            else if (suica == camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (suica < camaroes)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     3 Rodada: Brasil vs Suíça");

            Random random39 = new Random();
            // Armazena os gols de cada equipe
            int gbrasil = 0;
            int gsuica = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber39 = random39.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber39 < 80)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gbrasil++;
                }
                else if (randomNumber39 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gsuica++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Brasil: " + gbrasil + " - " + gsuica + " :Suíça");
            if (gbrasil > gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Brasil venceu!\n");
            }
            else if (gbrasil == gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gbrasil < gsuica)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     4 Rodada: Camarões vs Sérvia");

            Random random40 = new Random();
            // Armazena os gols de cada equipe
            int gcamaroes = 0;
            int gservia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber40 = random40.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber40 < 35)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gcamaroes++;
                }
                else if (randomNumber40 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gservia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Camarões: " + gcamaroes + " - " + gservia + " :Sérvia");
            if (gcamaroes > gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");
            }
            else if (gcamaroes == gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcamaroes < gservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     5 Rodada: Camarões vs Brasil");

            Random random41 = new Random();
            // Armazena os gols de cada equipe
            int ggcamaroes = 0;
            int ggbrasil = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber41 = random41.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber41 < 25)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggcamaroes++;
                }
                else if (randomNumber41 < 90)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggbrasil++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Camarões: " + ggcamaroes + " - " + ggbrasil + " :Brasil");
            if (ggcamaroes > ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Camarões venceu!\n");
            }
            else if (ggcamaroes == ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggcamaroes < ggbrasil)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     brasil venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;


            Console.WriteLine("\n\n     6 Rodada: Suíça vs Sérvia");

            Random random42 = new Random();
            // Armazena os gols de cada equipe
            int ggsuica = 0;
            int ggservia = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber42 = random42.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber42 < 55)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggsuica++;
                }
                else if (randomNumber42 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggservia++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Suíça: " + ggsuica + " - " + ggservia + " :Sérvia");
            if (ggsuica > ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Suíça venceu!\n");
            }
            else if (ggsuica == ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggsuica < ggservia)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Sérvia venceu!");

            }
            Console.ForegroundColor = ConsoleColor.White;
            int gbr = brasil + gbrasil + ggbrasil;
            int gsui = suica + gsuica + ggsuica;
            int gcam = camaroes + gcamaroes + ggcamaroes;
            int gser = servia + gservia + ggservia;

            int vbr = 0;
            int vsui = 0;
            int vcam = 0;
            int vser = 0;

            int ebr = 0;
            int esui = 0;
            int ecam = 0;
            int eser = 0;

            int dbr = 0;
            int dsui = 0;
            int dcam = 0;
            int dser = 0;

            int pbr = 0;
            int psui = 0;
            int pcam = 0;
            int pser = 0;


            if (brasil > servia)
            {
                vbr++;
                dser++;

            }
            else if (brasil == servia)
            {
                ebr++;
                eser++;

            }
            else if (brasil < servia)
            {
                vser++;
                dbr++;

            }
            /*-------------------------------------*/
            if (suica > camaroes)
            {
                vsui++;
                dcam++;
            }
            else if (suica == camaroes)
            {
                esui++;
                ecam++;

            }
            else if (suica < camaroes)
            {
                vcam++;
                dsui++;

            }
            /*-------------------------------------*/
            if (gbrasil > gsuica)
            {
                vbr++;
                dsui++;
            }
            else if (gbrasil == gsuica)
            {
                ebr++;
                esui++;

            }
            else if (gbrasil < gsuica)
            {
                vsui++;
                dbr++;

            }
            /*-------------------------------------*/
            if (gcamaroes > gservia)
            {
                vcam++;
                dser++;
            }
            else if (gcamaroes == gservia)
            {
                ecam++;
                eser++;

            }
            else if (gcamaroes < gservia)
            {
                vser++;
                dcam++;

            }
            /*-------------------------------------*/
            if (ggcamaroes > ggbrasil)
            {
                vcam++;
                dbr++;
            }
            else if (ggcamaroes == ggbrasil)
            {
                ecam++;
                ebr++;

            }
            else if (ggcamaroes < ggbrasil)
            {
                vbr++;
                dcam++;

            }
            /*-------------------------------------*/
            if (ggsuica > ggservia)
            {
                vsui++;
                dser++;
            }
            else if (ggsuica == ggservia)
            {
                esui++;
                eser++;

            }
            else if (ggsuica < ggservia)
            {

                vser++;
                dsui++;
            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (brasil > servia)
            {
                pbr += 3;
            }
            else if (brasil == servia)
            {
                pbr++;
                pser++;

            }
            else if (brasil < servia)
            {
                pser += 3;

            }
            /*-------------------------------------*/
            if (suica > camaroes)
            {
                psui += 3;
            }
            else if (suica == camaroes)
            {
                psui++;
                pcam++;

            }
            else if (suica < camaroes)
            {
                pcam += 3;

            }
            /*-------------------------------------*/
            if (gbrasil > gsuica)
            {
                pbr += 3;
            }
            else if (gbrasil == gsuica)
            {
                pbr++;
                psui++;

            }
            else if (gbrasil < gsuica)
            {
                psui += 3;

            }
            /*-------------------------------------*/
            if (gcamaroes > gservia)
            {
                pcam += 3;
            }
            else if (gcamaroes == gservia)
            {
                pcam++;
                pser++;

            }
            else if (gcamaroes < gservia)
            {
                pser += 3;

            }
            /*-------------------------------------*/
            if (ggcamaroes > ggbrasil)
            {
                pcam += 3;
            }
            else if (ggcamaroes == ggbrasil)
            {
                pcam++;
                pbr++;

            }
            else if (ggcamaroes < ggbrasil)
            {
                pbr += 3;

            }
            /*-------------------------------------*/
            if (ggsuica > ggservia)
            {
                psui += 3;
            }
            else if (ggsuica == ggservia)
            {
                psui++;
                pser++;

            }
            else if (ggsuica < ggservia)
            {

                pser += 3;

            }



            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  H      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Brasil       |  " + vbr + "  |  " + ebr + "  |  " + dbr + "  |  " + gbr + "  |  " + pbr + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Suiça        |  " + vsui + "  |  " + esui + "  |  " + dsui + "  |  " + gsui + "  |  " + psui + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Camarões      |  " + vcam + "  |  " + ecam + "  |  " + dcam + "  |  " + gcam + "  |  " + pcam + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Sérvia       |  " + vser + "  |  " + eser + "  |  " + dser + "  |  " + gser + "  |  " + pser + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\nGrupo: H");
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     1 Rodada: Portugal vs Gana");

            Random random43 = new Random();
            // Armazena os gols de cada equipe
            int portugal = 0;
            int gana = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber43 = random43.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber43 < 90)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    portugal++;
                }
                else if (randomNumber43 < 25)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gana++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


           

            Console.WriteLine("     Portugal: " + portugal + " - " + gana + " :Gana");
            if (portugal > gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (portugal == gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (portugal < gana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n\n     2 Rodada: Urguai vs Coreia do Sul");

            Random random44 = new Random();
            // Armazena os gols de cada equipe
            int uruguai = 0;
            int coreiasul = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber44 = random44.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber44 < 65)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    uruguai++;
                }
                else if (randomNumber44 < 45)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    coreiasul++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Uruguai: " + uruguai + " - " + coreiasul + " :coreia do sul");
            if (uruguai > coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");
            }
            else if (uruguai == coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (uruguai < coreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do sul venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     3 Rodada: Portugal vs Uruguai");

            Random random45 = new Random();
            // Armazena os gols de cada equipe
            int gportugal = 0;
            int guruguai = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber45 = random45.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber45 < 80)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gportugal++;
                }
                else if (randomNumber45 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    guruguai++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Portugal: " + gportugal + " - " + guruguai + " :Uruguai");
            if (gportugal > guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (gportugal == guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gportugal < guruguai)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     4 Rodada: Gana vs Coreia do Sul");

            Random random46 = new Random();
            // Armazena os gols de cada equipe
            int ggana = 0;
            int gcoreiasul = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber46 = random46.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber46 < 35)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggana++;
                }
                else if (randomNumber46 < 75)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gcoreiasul++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols


            Console.WriteLine("     Gana: " + ggana + " - " + gcoreiasul + " :Coreia do Sul");
            if (gcoreiasul > ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do sul venceu!\n");
            }
            else if (gcoreiasul == ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gcoreiasul < ggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     5 Rodada: Uruguai vs Gana");


            Random random47 = new Random();
            // Armazena os gols de cada equipe
            int gggana = 0;
            int gguruguai = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber47 = random47.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber47 < 45)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    gggana++;
                }
                else if (randomNumber47 < 60)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    gguruguai++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols

            Console.WriteLine("     Uruguai: " + gguruguai + " - " + gggana + " :Gana");
            if (gguruguai > gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Uruguai venceu!\n");
            }
            else if (gguruguai == gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (gguruguai < gggana)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Gana venceu!\n");

            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.WriteLine("\n\n     6 Rodada: Portugal vs coreia do sul");


            Random random48 = new Random();
            // Armazena os gols de cada equipe
            int ggportugal = 0;
            int ggcoreiasul = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber48 = random48.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber48 < 80)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    ggportugal++;
                }
                else if (randomNumber48 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    ggcoreiasul++;
                }
            }

            // Verifica qual equipe venceu baseado no número de gols

            Console.WriteLine("     Portugal: " + ggportugal + " - " + ggcoreiasul + " :Coreia do Sul");
            if (ggportugal > ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Portugal venceu!\n");
            }
            else if (ggportugal == ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");

            }
            else if (ggportugal < ggcoreiasul)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("     Coreia do Sul venceu!");

            }




            Console.ForegroundColor = ConsoleColor.White;
            int gCs = coreiasul + gcoreiasul + ggcoreiasul;
            int gPt = portugal + gportugal + ggportugal;
            int gUr = uruguai + guruguai + gguruguai;
            int gAn = gana + ggana + gggana;

            int vCs = 0;
            int vPt = 0;
            int vUr = 0;
            int vAn = 0;

            int eCs = 0;
            int ePt = 0;
            int eUr = 0;
            int eAn = 0;

            int dCs = 0;
            int dPt = 0;
            int dUr = 0;
            int dAn = 0;

            int pCs = 0;
            int pPt = 0;
            int pUr = 0;
            int pAn = 0;


            if (portugal > gana)
            {
                vPt++;
                dAn++;

            }
            else if (portugal == gana)
            {
                ePt++;
                eAn++;

            }
            else if (portugal < gana)
            {

                vAn++;
                dPt++;
            }
            /*-------------------------------------*/
            if (uruguai > coreiasul)
            {
                vUr++;
                dCs++;
            }
            else if (uruguai == coreiasul)
            {
                eUr++;
                eCs++;

            }
            else if (uruguai < coreiasul)
            {
                vCs++;
                dUr++;

            }
            /*-------------------------------------*/
            if (gportugal > guruguai)
            {
                vPt++;
                dUr++;
            }
            else if (gportugal == guruguai)
            {
                ePt++;
                eUr++;
            }
            else if (gportugal < guruguai)
            {
                vUr++;
                dPt++;

            }
            /*-------------------------------------*/
            if (gcoreiasul > ggana)
            {
                vCs++;
                dAn++;
            }
            else if (gcoreiasul == ggana)
            {
                eCs++;
                eAn++;

            }
            else if (gcoreiasul < ggana)
            {
                vAn++;
                dCs++;

            }
            /*-------------------------------------*/
            if (gguruguai > gggana)
            {
                vUr++;
                dAn++;

            }
            else if (gguruguai == gggana)
            {
                eUr++;
                eAn++;

            }
            else if (gguruguai < gggana)
            {
                vAn++;
                dUr++;

            }
            /*-------------------------------------*/
            if (ggportugal > ggcoreiasul)
            {
                vPt++;
                dCs++;

            }
            else if (ggportugal == ggcoreiasul)
            {
                ePt++;
                eCs++;

            }
            else if (ggportugal < ggcoreiasul)
            {

                vCs++;
                dPt++;
            }
            /*-------------------------------------*/
            /*-------------------------------------*/

            if (portugal > gana)
            {
                pPt += 3;

            }
            else if (portugal == gana)
            {
                pPt++;
                pAn++;
            }
            else if (portugal < gana)
            {
                pAn += 3;
            }
            /*-------------------------------------*/
            if (uruguai > coreiasul)
            {
                pUr += 3;
            }
            else if (uruguai == coreiasul)
            {
                pUr++;
                pCs++;

            }
            else if (uruguai < coreiasul)
            {
                pCs += 3;

            }
            /*-------------------------------------*/
            if (gportugal > guruguai)
            {
                pPt += 3;
            }
            else if (gportugal == guruguai)
            {
                pPt++;
                pUr++;
            }
            else if (gportugal < guruguai)
            {
                pUr += 3;

            }
            /*-------------------------------------*/
            if (gcoreiasul > ggana)
            {
                pCs += 3;
            }
            else if (gcoreiasul == ggana)
            {
                pCs++;
                pAn++;

            }
            else if (gcoreiasul < ggana)
            {
                pAn += 3;

            }
            /*-------------------------------------*/
            if (gguruguai > gggana)
            {
                pUr += 3;

            }
            else if (gguruguai == gggana)
            {
                pUr++;
                pAn++;

            }
            else if (gguruguai < gggana)
            {
                pAn += 3;

            }
            /*-------------------------------------*/
            if (ggportugal > ggcoreiasul)
            {
                pPt += 3;

            }
            else if (ggportugal == ggcoreiasul)
            {
                pPt++;
                pCs++;

            }
            else if (ggportugal < ggcoreiasul)
            {

                pCs += 3;

            }




            Console.WriteLine("\n\n\n\n _____________________________________________________");
            Console.WriteLine(" |      Group  H      |  V  |  E  |  D  |  GM | Pts | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |   Coreia Do Sul    |  " + vCs + "  |  " + eCs + "  |  " + dCs + "  |  " + gCs + "  |  " + pCs + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |     Portugal       |  " + vPt + "  |  " + ePt + "  |  " + dPt + "  |  " + gPt + "  |  " + pPt + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |      Uruguai       |  " + vUr + "  |  " + eUr + "  |  " + dUr + "  |  " + gUr + "  |  " + pUr + "  | ");
            Console.WriteLine(" |--------------------|-----|-----|-----|-----|-----| ");
            Console.WriteLine(" |       Gana         |  " + vAn + "  |  " + eAn + "  |  " + dAn + "  |  " + gAn + "  |  " + pAn + "  | ");
            Console.WriteLine(" |____________________|_____|_____|_____|_____|_____| \n\n\n");
            Console.ReadLine();
            Console.Clear();

            int gal1 = 0;
            int gal2 = 0;

            /* qatar = 1 
             * senegal = 2
             * equador = 3 
             * holanda = 3 */

            if (pQa > pSe && pQa > pEq && pQa > pHo)
            {

                gal1 = pQa;
                GrupoA[0] = "Qatar";

                if (pSe > pEq && pSe > pHo)
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Senegal";
                    gal2 = pSe;
                }
                else if (pEq > pSe && pEq > pHo)
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Equador";
                    gal2 = pEq;
                }
                else
                {
                    GrupoA[0] = "Qatar";
                    GrupoA[1] = "Holanda";
                    gal2 = pHo;
                }

            }
            else if (pSe > pQa && pSe > pEq && pSe > pHo)
            {

                gal1 = pSe;
                GrupoA[0] = "Senegal";
                if (pQa > pEq && pQa > pHo)
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Qatar";
                    gal2 = pQa;
                }
                else if (pEq > pQa && pEq > pHo)
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Equador";
                    gal2 = pEq;
                }
                else
                {
                    GrupoA[0] = "Senegal";
                    GrupoA[1] = "Holanda";
                    gal2 = pHo;
                }
            }
            else if (pEq > pQa && pEq > pSe && pEq > pHo)
            {
                gal1 = pEq;
                GrupoA[0] = "Equador";
                if (pQa > pSe && pQa > pHo)
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Qatar";
                    gal2 = pQa;
                }
                else if (pSe > pQa && pSe > pHo)
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Senegal";
                    gal2 = pSe;
                }
                else
                {
                    GrupoA[0] = "Equador";
                    GrupoA[1] = "Holanda";
                    gal2 = pHo;
                }
            }
            else
            {
                gal1 = pHo;
                GrupoA[0] = "Holanda";
                if (pQa > pSe && pQa > pEq)
                {
                    GrupoA[0] = "Holanda";
                    GrupoA[1] = "Qatar";
                    gal2 = pQa;
                }
                else if (pSe > pQa && pSe > pEq)
                {
                    GrupoA[0] = "Holanda";
                    GrupoA[1] = "Senegal";
                    gal2 = pSe;
                }
                else
                {
                    GrupoA[0] = "Holanda";
                    GrupoA[1] = "Equador";
                    gal2 = pEq;
                }
            }

            /* inglaterra = 1
               estados unidos = 2
               irã = 3
               Pais de gales = 4 */

            int gbl1 = 0;
            int gbl2 = 0;

            if (pIg > pEu && pIg > pIr && pIg > pPg)
            {
                gbl1 = pIg;
                GrupoB[0] = "Inglaterra";
                if (pEu > pIr && pEu > pPg)
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else if (pIr > pEu && pIr > pPg)
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "Irã";
                    gbl2 = pIr;
                }
                else
                {
                    GrupoB[0] = "Inglaterra";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else if (pEu > pIg && pEu > pIr && pEu > pPg)
            {
                gbl1 = pEu;
                GrupoB[0] = "Estados Unidos";

                if (pIg > pIr && pIg > pPg)
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "Inglaterra";
                    gbl2 = pIg;
                }
                else if (pIr > pIg && pIr > pPg)
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "Irã";
                    gbl2 = pIr;
                }
                else
                {
                    GrupoB[0] = "Estados Unidos";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else if (pIr > pIg && pIr > pEu && pIr > pPg)
            {
                gbl1 = pIr;
                GrupoB[0] = "Irã";
                if (pIg > pEu && pIg > pPg)
                {
                    GrupoB[0] = "Irã";
                    GrupoB[1] = "Inglaterra";
                    gbl2 = pIg;
                }
                else if (pEu > pIg && pEu > pPg)
                {
                    GrupoB[0] = "Irã";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else
                {
                    GrupoB[0] = "Irã";
                    GrupoB[1] = "País de Gales";
                    gbl2 = pPg;
                }
            }
            else
            {
                gbl1 = pPg;
                GrupoB[0] = "País de Gales";
                if (pIg > pEu && pIg > pIr)
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Inglerra";
                    gbl2 = pIg;
                }
                else if (pEu > pIg && pEu > pIr)
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Estados Unidos";
                    gbl2 = pEu;
                }
                else
                {
                    GrupoB[0] = "País de Gales";
                    GrupoB[1] = "Irã";
                    gbl2 = pIr;
                }
            }

            /* Argentina = 1
             * Polonia = 2
             * mexico = 3
             * Arabia  = 4 */
            int gcl1 = 0;
            int gcl2 = 0;

            if (pAg > pPo && pAg > pMe && pAg > pAr)
            {
                gcl1 = pAg;
                GrupoC[0] = "Argentina";

                if (pPo > pMe && pPo > pAr)
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else if (pMe > pPo && pMe > pAr)
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
                else
                {
                    GrupoC[0] = "Argentina";
                    GrupoC[1] = "Arabia";
                    gcl2 = pAr;
                }
            }
            else if (pPo > pAg && pPo > pMe && pPo > pAr)
            {
                gcl1 = pPo;
                GrupoC[0] = "Polonia";

                if (pAg > pMe && pAg > pAr)
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pMe > pAg && pMe > pAr)
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
                else
                {
                    GrupoC[0] = "Polonia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAr;
                }
            }
            else if (pMe > pAg && pMe > pPo && pMe > pAr)
            {
                gcl1 = pMe;
                GrupoC[0] = "Mexico";

                if (pAg > pPo && pAg > pAr)
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pPo > pAg && pPo > pAr)
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else
                {
                    GrupoC[0] = "Mexico";
                    GrupoC[1] = "Arabia";
                    gcl2 = pAr;
                }
            }
            else
            {
                gcl1 = pAr;
                GrupoC[0] = "Arabia";

                if (pAg > pPo && pAg > pMe)
                {
                    GrupoC[0] = "Arabia";
                    GrupoC[1] = "Argentina";
                    gcl2 = pAg;
                }
                else if (pPo > pAg && pPo > pMe)
                {
                    GrupoC[0] = "Arabia";
                    GrupoC[1] = "Polonia";
                    gcl2 = pPo;
                }
                else
                {
                    GrupoC[0] = "Arabia";
                    GrupoC[1] = "Mexico";
                    gcl2 = pMe;
                }
            }
            /* França = 1
             * australia = 2
             * tunisia = 3
             * dinamarca  = 4 */

            int gdl1 = 0;
            int gdl2 = 0;

            if (pFr > pAu && pFr > pTu && pFr > pDi)
            {
                gdl1 = pFr;
                GrupoD[0] = "França";

                if (pAu > pTu && pAu > pDi)
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else if (pTu > pAu && pTu > pDi)
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
                else
                {
                    GrupoD[0] = "França";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else if (pAu > pFr && pAu > pTu && pAu > pDi)
            {
                gdl1 = pAu;
                GrupoD[0] = "Australia";
                if (pFr > pTu && pFr > pDi)
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pTu > pFr && pTu > pDi)
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
                else
                {
                    GrupoD[0] = "Australia";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else if (pTu > pFr && pTu > pAu && pTu > pDi)
            {
                gdl1 = pTu;
                GrupoD[0] = "Tunisia";
                if (pFr > pAu && pFr > pDi)
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pAu > pFr && pAu > pDi)
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else
                {
                    GrupoD[0] = "Tunisia";
                    GrupoD[1] = "Dinamarca";
                    gdl2 = pDi;
                }
            }
            else
            {
                gdl1 = pDi;
                GrupoD[0] = "Dinamarca";

                if (pFr > pAu && pFr > pTu)
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "França";
                    gdl2 = pFr;
                }
                else if (pAu > pFr && pAu > pTu)
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "Australia";
                    gdl2 = pAu;
                }
                else
                {
                    GrupoD[0] = "Dinamarca";
                    GrupoD[1] = "Tunisia";
                    gdl2 = pTu;
                }
            }
            /* japao = 1
             * espanha = 2
             * alemanha = 3
             * costarica = 4 */
            int gel1 = 0;
            int gel2 = 0;

            if (pjap > pes && pjap > pale && pjap > pcos)
            {
                gel1 = pjap;
                GrupoE[0] = "Japão";

                if (pes > pale && pes > pcos)
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else if (pale > pes && pale > pcos)
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
                else
                {
                    GrupoE[0] = "Japão";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else if (pes > pjap && pes > pale && pes > pcos)
            {
                gel1 = pes;
                GrupoE[0] = "Espanha";

                if (pjap > pale && pjap > pcos)
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pale > pjap && pale > pcos)
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
                else
                {
                    GrupoE[0] = "Espanha";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else if (pale > pjap && pale > pes && pale > pcos)
            {
                gel1 = pale;
                GrupoE[0] = "Alemanha";

                if (pjap > pes && pjap > pcos)
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pes > pjap && pes > pcos)
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else
                {
                    GrupoE[0] = "Alemanha";
                    GrupoE[1] = "Costa Rica";
                    gel2 = pcos;
                }
            }
            else
            {
                gel1 = pcos;
                GrupoA[0] = "Costa Rica";

                if (pjap > pes && pjap > pale)
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Japão";
                    gel2 = pjap;
                }
                else if (pes > pjap && pes > pale)
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Espanha";
                    gel2 = pes;
                }
                else
                {
                    GrupoE[0] = "Costa Rica";
                    GrupoE[1] = "Alemanha";
                    gel2 = pale;
                }
            }
            /* marrocos = 1
            * croatia = 2
            * belgica = 3
            * canada = 4 */
            int gfl1 = 0;
            int gfl2 = 0;

            if (pmar > pcro && pmar > pbel && pmar > pcan)
            {
                gfl1 = pmar;
                GrupoF[0] = "Marrocos";

                if (pcro > pbel && pcro > pcan)
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else if (pbel > pcro && pbel > pcan)
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
                else
                {
                    GrupoF[0] = "Marrocos";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else if (pcro > pmar && pcro > pbel && pcro > pcan)
            {
                gfl1 = pcro;
                GrupoF[0] = "Croacia";

                if (pmar > pbel && pmar > pcan)
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pbel > pmar && pbel > pcan)
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
                else
                {
                    GrupoF[0] = "Croacia";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else if (pbel > pmar && pbel > pcro && pbel > pcan)
            {
                gfl1 = pbel;
                GrupoF[0] = "Belgica";

                if (pmar > pcro && pmar > pcan)
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pcro > pmar && pcro > pcan)
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else
                {
                    GrupoF[0] = "Belgica";
                    GrupoF[1] = "Canada";
                    gfl2 = pcan;
                }
            }
            else
            {
                gfl1 = pcan;
                GrupoF[0] = "Canada";

                if (pmar > pcro && pmar > pbel)
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Marrocos";
                    gfl2 = pmar;
                }
                else if (pcro > pmar && pcro > pbel)
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Croacia";
                    gfl2 = pcro;
                }
                else
                {
                    GrupoF[0] = "Canada";
                    GrupoF[1] = "Belgica";
                    gfl2 = pbel;
                }
            }
            /* Brasil = 1
            * suica = 2
            * camaroes = 3
            * servia = 4 */
            int ggl1 = 0;
            int ggl2 = 0;

            if (pbr > psui && pbr > pcam && pbr > pser)
            {
                ggl1 = pbr;
                GrupoG[0] = "Brasil";

                if (psui > pcam && psui > pser)
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else if (pcam > psui && pcam > pser)
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
                else
                {
                    GrupoG[0] = "Brasil";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else if (psui > pbr && psui > pcam && psui > pser)
            {
                ggl1 = psui;
                GrupoG[0] = "Suiça";

                if (pbr > pcam && pbr > pser)
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (pcam > pbr && pcam > pser)
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
                else
                {
                    GrupoG[0] = "Suiça";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else if (pcam > pbr && pcam > psui && pcam > pser)
            {
                ggl1 = pcam;
                GrupoG[0] = "Camarões";

                if (pbr > psui && pbr > pser)
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (psui > pbr && psui > pser)
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else
                {
                    GrupoG[0] = "Camarões";
                    GrupoG[1] = "Servia";
                    ggl2 = pser;
                }
            }
            else
            {
                ggl1 = pser;
                GrupoG[0] = "Servia";

                if (pbr > psui && pbr > pcam)
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Brasil";
                    ggl2 = pbr;
                }
                else if (psui > pbr && psui > pcam)
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Suiça";
                    ggl2 = psui;
                }
                else
                {
                    GrupoG[0] = "Servia";
                    GrupoG[1] = "Camarões";
                    ggl2 = pcam;
                }
            }

            /* coreia = 1
            * portugal = 2
            * uruguai = 3
            * gana = 4 */
            int ghl1 = 0;
            int ghl2 = 0;
            if (pCs > pPt && pCs > pUr && pCs > pAn)
            {
                ghl1 = pCs;
                GrupoH[0] = "Coreia Do Sul";

                if (pPt > pUr && pPt > pAn)
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else if (pUr > pPt && pUr > pAn)
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
                else
                {
                    GrupoH[0] = "Coreia Do Sul";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else if (pPt > pCs && pPt > pUr && pPt > pAn)
            {
                ghl1 = pPt;
                GrupoH[0] = "Portugal";

                if (pCs > pUr && pCs > pAn)
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pUr > pCs && pUr > pAn)
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
                else
                {
                    GrupoH[0] = "Portugal";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else if (pUr > pCs && pUr > pPt && pUr > pAn)
            {
                ghl1 = pUr;
                GrupoH[0] = "Uruguai";

                if (pCs > pPt && pCs > pAn)
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pPt > pCs && pPt > pAn)
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else
                {
                    GrupoH[0] = "Uruguai";
                    GrupoH[1] = "Gana";
                    ghl2 = pAn;
                }
            }
            else
            {
                ghl1 = pAn;
                GrupoH[0] = "Gana";

                if (pCs > pPt && pCs > pUr)
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Coreia do Sul";
                    ghl2 = pCs;
                }
                else if (pPt > pCs && pPt > pUr)
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Portugal";
                    ghl2 = pPt;
                }
                else
                {
                    GrupoH[0] = "Gana";
                    GrupoH[1] = "Uruguai";
                    ghl2 = pUr;
                }
            }



            Console.WriteLine(" ________________________                   ________________________                                                                                                                                                                                                  ");
            Console.WriteLine("|    Oitavas de Final    |                 |    Quartas de Final    |                                                                                                                                                                                                 ");
            Console.WriteLine("|------------------------|                 |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("|------------------------|                                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoA[1] + "                                                                                                                                                                                                                                                         ");
            Console.WriteLine("|           -            |--------------|                                                                                                                                                                                                                             ");
            Console.WriteLine("         " + GrupoB[0] + "                           |  |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("|________________________|              |  |      Classificado      |                                                                                                                                                                                                 ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      Classificado      |              |               ________________________                                                                                                                                           ");
            Console.WriteLine("|------------------------|              |  |________________________|              |              |        Semi Finas      |                                                                                                                                          ");
            Console.WriteLine("         " + GrupoC[1] + "                          |                                          |              |------------------------|                                                                                                                                          ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("                                                                                   |              |      Classificado      |                                                                                                                                          ");
            Console.WriteLine("                                                                                   ---------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      Classificado      |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |________________________|                       |      ________________________                                                                                    ");
            Console.WriteLine("|------------------------|                                                         |                                                               |     |          Finas         |                             _______________________                               ");
            Console.WriteLine("         " + GrupoE[1] + "                                                                  |                                                               |     |------------------------|                            |        Vencedor       |                              ");
            Console.WriteLine("|           -            |---------------|                                         |                                                               |     |      Classificado      |                            |-----------------------|                              ");
            Console.WriteLine("         " + GrupoF[0] + "                        |  |------------------------|             |                                                               ------|           -            | ---------------------------|      Classificado     |                              ");
            Console.WriteLine("|________________________|               |  |      Classificado      |             |                                                               |     |      Classificado      |                            |_______________________|                              ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                               |     |________________________|                                                                                   ");
            Console.WriteLine("                                         |  |      Classificado      |                                                                             |                                                                                                                  ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                             |                                                                                                                  ");
            Console.WriteLine("         " + GrupoG[1] + "                           |                                                                                                         |                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                                                                                         |                                                                                                                  ");
            Console.WriteLine("         " + GrupoH[0] + "                                                                                                                                     |                                                                                                                  ");
            Console.WriteLine("|________________________|                                                                        |________________________|                       |                                                                                                                  ");
            Console.WriteLine("                                                                                                  |      Classificado      |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |--------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      Classificado      |                                                                                                                                          ");
            Console.WriteLine("|------------------------|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("         " + GrupoB[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |--------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoA[0] + "                          |  |------------------------|              |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|              |  |      Classificado      |              |                                                                                                                                                                                  ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      Classificado      |              |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|              |  |________________________|              |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[1] + "                          |                                          |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoC[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoF[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoE[0] + "                           |  |------------------------|             |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|               |  |      Classificado      |             |                                                                                                                                                                                  ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                         |  |      Classificado      |                                                                                                                                                                                                ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                                                                                                                                                ");
            Console.WriteLine("         " + GrupoH[1] + "                           |                                                                                                                                                                                                                            ");
            Console.WriteLine("|           -            |---------------|                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoG[0] + "                                                                                                                                                                                                                                                        ");
            Console.WriteLine("|________________________|                                                                                                                                                                                                                                            ");

            Console.ReadLine();
            Console.Clear();


            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS PRIMEIRA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoA[1] + " vs " + GrupoB[0]);



            Random random1000 = new Random();

            // Armazena os gols de cada equipe
            int equipa1 = 0;
            int equipa2 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1000 = random1000.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1000 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa1++;
                }
                else if (randomNumber1000 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa2++;
                }
            }


            Console.WriteLine("     " + GrupoA[1] + ": " + equipa1 + " - " + equipa2 + " :" + GrupoB[0]);
            if (equipa1 > equipa2)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoA[1] + "     venceu!\n");
                jogoQuarta1 = GrupoA[1];
            }
            else if (equipa1 == equipa2)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas1 = new Random();

                if (equipa1 == equipa2)
                {
                    int randomNumberoitavas1 = rndoitavas1.Next(0, 2);
                    if (randomNumberoitavas1 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoA[1] + " venceu as penalidades");
                        jogoQuarta1 = GrupoA[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoB[0] + " venceu as penalidades");
                        jogoQuarta1 = GrupoB[0];
                    }
                }
            }
            else if (equipa1 < equipa2)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoB[0] + "      venceu!\n");
                jogoQuarta1 = GrupoB[0];
            }



            Console.ForegroundColor = ConsoleColor.White;


            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS SEGUNDA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoC[1] + " vs " + GrupoD[0]);



            Random random1001 = new Random();

            // Armazena os gols de cada equipe
            int equipa3 = 0;
            int equipa4 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1001 = random1001.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1001 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa3++;
                }
                else if (randomNumber1001 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa4++;
                }
            }


            Console.WriteLine("     " + GrupoC[1] + ": " + equipa3 + " - " + equipa4 + " :" + GrupoD[0]);
            if (equipa3 > equipa4)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoC[1] + "     venceu!\n");
                jogoQuarta2 = GrupoC[1];
            }
            else if (equipa3 == equipa4)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas2 = new Random();

                if (equipa3 == equipa4)
                {
                    int randomNumberoitavas2 = rndoitavas2.Next(0, 2);
                    if (randomNumberoitavas2 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoC[1] + " venceu as penalidades");
                        jogoQuarta2 = GrupoC[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoD[0] + " venceu as penalidades");
                        jogoQuarta2 = GrupoD[0];
                    }
                }


            }
            else if (equipa3 < equipa4)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoD[0] + "      venceu!\n");
                jogoQuarta2 = GrupoD[0];

            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS TERCEIRA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoE[1] + " vs " + GrupoF[0]);


            Random random1003 = new Random();

            // Armazena os gols de cada equipe
            int equipa5 = 0;
            int equipa6 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1003 = random1003.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1003 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa5++;
                }
                else if (randomNumber1003 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa6++;
                }
            }

            Console.WriteLine("     " + GrupoE[1] + ": " + equipa5 + " - " + equipa6 + " :" + GrupoF[0]);
            if (equipa5 > equipa6)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoE[1] + "     venceu!\n");
                jogoQuarta3 = GrupoE[1];
            }
            else if (equipa5 == equipa6)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas3 = new Random();

                if (equipa5 == equipa6)
                {
                    int randomNumberoitavas3 = rndoitavas3.Next(0, 2);
                    if (randomNumberoitavas3 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoE[1] + " venceu as penalidades");
                        jogoQuarta3 = GrupoE[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoF[0] + " venceu as penalidades");
                        jogoQuarta3 = GrupoF[0];
                    }
                }

            }
            else if (equipa5 < equipa6)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoF[0] + "      venceu!\n");
                jogoQuarta3 = GrupoF[0];
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS QUARTA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoG[1] + " vs " + GrupoH[0]);


            Random random1004 = new Random();
            // Armazena os gols de cada equipe
            int equipa7 = 0;
            int equipa8 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1004 = random1004.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1004 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa7++;
                }
                else if (randomNumber1004 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa8++;
                }
            }


            Console.WriteLine("     " + GrupoG[1] + ": " + equipa7 + " - " + equipa8 + " :" + GrupoH[0]);

            if (equipa7 > equipa8)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoG[1] + "     venceu!\n");
                jogoQuarta4 = GrupoG[1];
            }
            else if (equipa7 == equipa8)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas4 = new Random();

                if (equipa7 == equipa8)
                {
                    int randomNumberoitavas4 = rndoitavas4.Next(0, 2);
                    if (randomNumberoitavas4 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoG[1] + " venceu as penalidades");
                        jogoQuarta4 = GrupoG[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoH[0] + " venceu as penalidades");
                        jogoQuarta4 = GrupoH[0];
                    }
                }

            }
            else if (equipa7 < equipa8)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoH[0] + "      venceu!\n");
                jogoQuarta4 = GrupoH[0];
            }
            Console.ForegroundColor = ConsoleColor.White;




            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS QUINTA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoB[1] + " vs " + GrupoA[0]);



            Random random1005 = new Random();
            // Armazena os gols de cada equipe
            int equipa10 = 0;
            int equipa9 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1005 = random1005.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1005 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa10++;
                }
                else if (randomNumber1005 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa9++;
                }
            }


            Console.WriteLine("     " + GrupoB[1] + ": " + equipa10 + " - " + equipa9 + " :" + GrupoA[0]);
            if (equipa9 > equipa10)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoA[0] + "     venceu!\n");
                jogoQuarta5 = GrupoA[0];
            }
            else if (equipa9 == equipa10)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas5 = new Random();

                if (equipa9 == equipa10)
                {
                    int randomNumberoitavas5 = rndoitavas5.Next(0, 2);
                    if (randomNumberoitavas5 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoB[1] + " venceu as penalidades");
                        jogoQuarta5 = GrupoB[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoA[0] + " venceu as penalidades");
                        jogoQuarta5 = GrupoA[0];
                    }
                }

            }
            else if (equipa9 < equipa10)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoB[1] + "      venceu!\n");
                jogoQuarta5 = GrupoB[1];
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS SEXTA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoD[1] + " vs " + GrupoC[0]);



            Random random1006 = new Random();
            // Armazena os gols de cada equipe
            int equipa12 = 0;
            int equipa11 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1006 = random1006.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1006 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa12++;
                }
                else if (randomNumber1006 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa11++;
                }
            }

            Console.WriteLine("     " + GrupoD[1] + ": " + equipa12 + " - " + equipa11 + " :" + GrupoC[0]);
            if (equipa11 > equipa12)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoC[0] + "     venceu!\n");
                jogoQuarta6 = GrupoC[0];
            }
            else if (equipa11 == equipa12)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas6 = new Random();

                if (equipa11 == equipa12)
                {
                    int randomNumberoitavas6 = rndoitavas6.Next(0, 2);
                    if (randomNumberoitavas6 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoD[1] + " venceu as penalidades");
                        jogoQuarta6 = GrupoD[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoC[0] + " venceu as penalidades");
                        jogoQuarta6 = GrupoG[0];
                    }
                }

            }
            else if (equipa11 < equipa12)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoD[1] + "      venceu!\n");
                jogoQuarta6 = GrupoD[1];
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS SETIMA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoF[1] + " vs " + GrupoE[0]);



            Random random1007 = new Random();
            // Armazena os gols de cada equipe
            int equipa14 = 0;
            int equipa13 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1007 = random1007.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1007 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa14++;
                }
                else if (randomNumber1007 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa13++;
                }
            }


            Console.WriteLine("     " + GrupoF[1] + ": " + equipa14 + " - " + equipa13 + " :" + GrupoE[0]);
            if (equipa13 > equipa14)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoE[0] + "     venceu!\n");
                jogoQuarta7 = GrupoE[0];
            }
            else if (equipa13 == equipa14)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas7 = new Random();

                if (equipa13 == equipa14)
                {
                    int randomNumberoitavas7 = rndoitavas7.Next(0, 2);
                    if (randomNumberoitavas7 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoF[1] + " venceu as penalidades");
                        jogoQuarta7 = GrupoF[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoE[0] + " venceu as penalidades");
                        jogoQuarta7 = GrupoE[0];
                    }
                }

            }
            else if (equipa13 < equipa14)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoF[1] + "      venceu!\n");
                jogoQuarta7 = GrupoF[1];
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n     OITAVAS OITAVA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + GrupoH[1] + " vs " + GrupoG[0]);



            Random random1008 = new Random();
            // Armazena os gols de cada equipe
            int equipa15 = 0;
            int equipa16 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1008 = random1008.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1008 < 70)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa15++;
                }
                else if (randomNumber1008 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa16++;
                }
            }


            Console.WriteLine("     " + GrupoH[1] + ": " + equipa15 + " - " + equipa16 + " :" + GrupoG[0]);
            if (equipa15 > equipa16)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoG[0] + "     venceu!\n");
                jogoQuarta8 = GrupoG[0];
            }
            else if (equipa15 == equipa16)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndoitavas8 = new Random();

                if (equipa15 == equipa16)
                {
                    int randomNumberoitavas8 = rndoitavas8.Next(0, 2);
                    if (randomNumberoitavas8 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoH[1] + " venceu as penalidades");
                        jogoQuarta8 = GrupoH[1];
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + GrupoG[0] + " venceu as penalidades");
                        jogoQuarta8 = GrupoG[0];
                    }
                }

            }
            else if (equipa15 < equipa16)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(GrupoH[1] + "      venceu!\n");
                jogoQuarta8 = GrupoH[1];
            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadLine();
            Console.Clear();



            Console.WriteLine(" ________________________                   ________________________                                                                                                                                                                                                  ");
            Console.WriteLine("|    Oitavas de Final    |                 |    Quartas de Final    |                                                                                                                                                                                                 ");
            Console.WriteLine("|------------------------|                 |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("|------------------------|                                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoA[1] + "                                                                                                                                                                                                                                                         ");
            Console.WriteLine("|           -            |--------------|                                                                                                                                                                                                                             ");
            Console.WriteLine("         " + GrupoB[0] + "                           |  |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("|________________________|              |  |      " + jogoQuarta1 + "      |                                                                                                                                                                                                 ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      " + jogoQuarta2 + "     |              |               ________________________                                                                                                                                           ");
            Console.WriteLine("|------------------------|              |  |________________________|              |              |        Semi Finas      |                                                                                                                                          ");
            Console.WriteLine("         " + GrupoC[1] + "                          |                                          |              |------------------------|                                                                                                                                          ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi1 + "     |                                                                                                                                          ");
            Console.WriteLine("                                                                                   ---------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi2 + "     |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |________________________|                       |      ________________________                                                                                    ");
            Console.WriteLine("|------------------------|                                                         |                                                               |     |          Finas         |                             _______________________                               ");
            Console.WriteLine("         " + GrupoE[1] + "                                                                  |                                                               |     |------------------------|                            |        Vencedor       |                              ");
            Console.WriteLine("|           -            |---------------|                                         |                                                               |     |      Classificado      |                            |-----------------------|                              ");
            Console.WriteLine("         " + GrupoF[0] + "                        |  |------------------------|             |                                                               ------|           -            | ---------------------------|      Classificado     |                              ");
            Console.WriteLine("|________________________|               |  |      " + jogoQuarta3 + "      |             |                                                               |     |      Classificado      |                            |_______________________|                              ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                               |     |________________________|                                                                                   ");
            Console.WriteLine("                                         |  |      " + jogoQuarta4 + "      |                                                                             |                                                                                                                  ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                             |                                                                                                                  ");
            Console.WriteLine("         " + GrupoG[1] + "                           |                                                                                                         |                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                                                                                         |                                                                                                                  ");
            Console.WriteLine("         " + GrupoH[0] + "                                                                                                                                     |                                                                                                                  ");
            Console.WriteLine("|________________________|                                                                        |________________________|                       |                                                                                                                  ");
            Console.WriteLine("                                                                                                  |      " + jogoSemi3 + "     |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |--------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi4 + "     |                                                                                                                                          ");
            Console.WriteLine("|------------------------|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("         " + GrupoB[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |--------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoA[0] + "                          |  |------------------------|              |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|              |  |      " + jogoQuarta5 + "      |              |                                                                                                                                                                                  ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      " + jogoQuarta6 + "      |              |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|              |  |________________________|              |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[1] + "                          |                                          |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoC[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoF[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoE[0] + "                           |  |------------------------|             |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|               |  |      " + jogoQuarta7 + "      |             |                                                                                                                                                                                  ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                         |  |      " + jogoQuarta8 + "      |                                                                                                                                                                                                ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                                                                                                                                                ");
            Console.WriteLine("         " + GrupoH[1] + "                           |                                                                                                                                                                                                                            ");
            Console.WriteLine("|           -            |---------------|                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoG[0] + "                                                                                                                                                                                                                                                        ");
            Console.WriteLine("|________________________|                                                                                                                       ");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n     QUARTAS PRIMEIRA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoQuarta1 + " vs " + jogoQuarta2);



            Random random1009 = new Random();
            // Armazena os gols de cada equipe
            int equipa25 = 0;
            int equipa26 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber1009 = random1008.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber1009 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa25++;
                }
                else if (randomNumber1009 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa26++;
                }
            }


            Console.WriteLine("     " + jogoQuarta1 + ": " + equipa25 + " - " + equipa26 + " :" + jogoQuarta2);
            if (equipa25 > equipa26)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta1 + "     venceu!\n");
                jogoSemi1 = jogoQuarta1;
            }
            else if (equipa25 == equipa26)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndQuarta1 = new Random();

                if (equipa25 == equipa26)
                {
                    int randomNumberQuarta1 = rndQuarta1.Next(0, 2);
                    if (randomNumberQuarta1 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta1 + " venceu as penalidades");
                        jogoSemi1 = jogoQuarta1;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta2 + " venceu as penalidades");
                        jogoSemi1 = jogoQuarta2;
                    }
                }

            }
            else if (equipa25 < equipa26)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta2 + "      venceu!\n");
                jogoSemi1 = jogoQuarta2;
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n     QUARTAS SEGUNDA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoQuarta3 + " vs " + jogoQuarta4);



            Random random10010 = new Random();
            // Armazena os gols de cada equipe
            int equipa27 = 0;
            int equipa28 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10010 = random10010.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10010 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa27++;
                }
                else if (randomNumber10010 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa28++;
                }
            }


            Console.WriteLine("     " + jogoQuarta3 + ": " + equipa27 + " - " + equipa28 + " :" + jogoQuarta4);
            if (equipa27 > equipa28)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta3 + "     venceu!\n");
                jogoSemi2 = jogoQuarta3;
            }
            else if (equipa27 == equipa28)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndQuarta2 = new Random();

                if (equipa27 == equipa28)
                {
                    int randomNumberQuarta2 = rndQuarta2.Next(0, 2);
                    if (randomNumberQuarta2 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta3 + " venceu as penalidades");
                        jogoSemi2 = jogoQuarta3;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta4 + " venceu as penalidades");
                        jogoSemi2 = jogoQuarta4;
                    }
                }

            }
            else if (equipa27 < equipa28)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta4 + "      venceu!\n");
                jogoSemi2 = jogoQuarta4;
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n     QUARTAS TERCEIRA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoQuarta5 + " vs " + jogoQuarta6);



            Random random10011 = new Random();
            // Armazena os gols de cada equipe
            int equipa29 = 0;
            int equipa30 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10011 = random10011.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10011 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa29++;
                }
                else if (randomNumber10011 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa30++;
                }
            }


            Console.WriteLine("     " + jogoQuarta5 + ": " + equipa29 + " - " + equipa30 + " :" + jogoQuarta6);
            if (equipa29 > equipa30)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta5 + "     venceu!\n");
                jogoSemi3 = jogoQuarta5;
            }
            else if (equipa29 == equipa30)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndQuarta3 = new Random();

                if (equipa29 == equipa30)
                {
                    int randomNumberQuarta3 = rndQuarta3.Next(0, 2);
                    if (randomNumberQuarta3 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta5 + " venceu as penalidades");
                        jogoSemi3 = jogoQuarta5;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta6 + " venceu as penalidades");
                        jogoSemi3 = jogoQuarta6;
                    }
                }

            }
            else if (equipa29 < equipa30)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta6 + "      venceu!\n");
                jogoSemi3 = jogoQuarta6;
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n     QUARTAS QUARTA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoQuarta7 + " vs " + jogoQuarta8);



            Random random10012 = new Random();
            // Armazena os gols de cada equipe
            int equipa31 = 0;
            int equipa32 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10012 = random10012.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10012 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa31++;
                }
                else if (randomNumber10012 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa32++;
                }
            }


            Console.WriteLine("     " + jogoQuarta7 + ": " + equipa31 + " - " + equipa32 + " :" + jogoQuarta8);
            if (equipa31 > equipa32)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta7 + "     venceu!\n");
                jogoSemi4 = jogoQuarta7;
            }
            else if (equipa31 == equipa32)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndQuarta4 = new Random();

                if (equipa31 == equipa32)
                {
                    int randomNumberQuarta4 = rndQuarta4.Next(0, 2);
                    if (randomNumberQuarta4 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta7 + " venceu as penalidades");
                        jogoSemi4 = jogoQuarta7;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoQuarta8 + " venceu as penalidades");
                        jogoSemi4 = jogoQuarta8;
                    }
                }

            }
            else if (equipa31 < equipa32)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoQuarta8 + "      venceu!\n");
                jogoSemi4 = jogoQuarta8;
            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadLine();
            Console.Clear();

            Console.WriteLine(" ________________________                   ________________________                                                                                                                                                                                                  ");
            Console.WriteLine("|    Oitavas de Final    |                 |    Quartas de Final    |                                                                                                                                                                                                 ");
            Console.WriteLine("|------------------------|                 |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("|------------------------|                                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoA[1] + "                                                                                                                                                                                                                                                         ");
            Console.WriteLine("|           -            |--------------|                                                                                                                                                                                                                             ");
            Console.WriteLine("         " + GrupoB[0] + "                           |  |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("|________________________|              |  |      " + jogoQuarta1 + "      |                                                                                                                                                                                                 ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      " + jogoQuarta2 + "     |              |               ________________________                                                                                                                                           ");
            Console.WriteLine("|------------------------|              |  |________________________|              |              |        Semi Finas      |                                                                                                                                          ");
            Console.WriteLine("         " + GrupoC[1] + "                          |                                          |              |------------------------|                                                                                                                                          ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi1 + "     |                                                                                                                                          ");
            Console.WriteLine("                                                                                   ---------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi2 + "     |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |________________________|                       |      ________________________                                                                                    ");
            Console.WriteLine("|------------------------|                                                         |                                                               |     |          Finas         |                             _______________________                               ");
            Console.WriteLine("         " + GrupoE[1] + "                                                                  |                                                               |     |------------------------|                            |        Vencedor       |                              ");
            Console.WriteLine("|           -            |---------------|                                         |                                                               |     |" + jogoFinal1 + "      |                            |-----------------------|                              ");
            Console.WriteLine("         " + GrupoF[0] + "                        |  |------------------------|             |                                                               ------|           -            | ---------------------------|      Classificado     |                              ");
            Console.WriteLine("|________________________|               |  |      " + jogoQuarta3 + "      |             |                                                               |     |" + jogoFinal2 + "      |                            |_______________________|                              ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                               |     |________________________|                                                                                   ");
            Console.WriteLine("                                         |  |      " + jogoQuarta4 + "      |                                                                             |                                                                                                                  ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                             |                                                                                                                  ");
            Console.WriteLine("         " + GrupoG[1] + "                           |                                                                                                         |                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                                                                                         |                                                                                                                  ");
            Console.WriteLine("         " + GrupoH[0] + "                                                                                                                                     |                                                                                                                  ");
            Console.WriteLine("|________________________|                                                                        |________________________|                       |                                                                                                                  ");
            Console.WriteLine("                                                                                                  |      " + jogoSemi3 + "     |                       |                                                                                                                  ");
            Console.WriteLine("                                                                                   |--------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |      " + jogoSemi4 + "     |                                                                                                                                          ");
            Console.WriteLine("|------------------------|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("         " + GrupoB[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |--------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoA[0] + "                          |  |------------------------|              |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|              |  |      " + jogoQuarta5 + "      |              |                                                                                                                                                                                  ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |  |      " + jogoQuarta6 + "      |              |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|              |  |________________________|              |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[1] + "                          |                                          |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoC[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoF[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoE[0] + "                           |  |------------------------|             |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|               |  |      " + jogoQuarta7 + "      |             |                                                                                                                                                                                  ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                         |  |      " + jogoQuarta8 + "      |                                                                                                                                                                                                ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                                                                                                                                                ");
            Console.WriteLine("         " + GrupoH[1] + "                           |                                                                                                                                                                                                                            ");
            Console.WriteLine("|           -            |---------------|                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoG[0] + "                                                                                                                                                                                                                                                        ");
            Console.WriteLine("|________________________|                                                                                                                       ");
            Console.ReadLine();
            Console.Clear();


            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n     SEMI PRIMEIRA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoSemi1 + " vs " + jogoSemi2);



            Random random10013 = new Random();
            // Armazena os gols de cada equipe
            int equipa40 = 0;
            int equipa41 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10013 = random10013.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10013 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa40++;
                }
                else if (randomNumber10013 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa41++;
                }
            }


            Console.WriteLine("     " + jogoSemi1 + ": " + equipa40 + " - " + equipa41 + " :" + jogoSemi2);
            if (equipa40 > equipa41)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoSemi1 + "     venceu!\n");
                jogoFinal1 = jogoSemi1;
            }
            else if (equipa40 == equipa41)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndsemi1 = new Random();

                if (equipa40 == equipa41)
                {
                    int randomNumberSemi1 = rndsemi1.Next(0, 2);
                    if (randomNumberSemi1 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoSemi1 + " venceu as penalidades");
                        jogoFinal1 = jogoSemi1;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoSemi2 + " venceu as penalidades");
                        jogoFinal1 = jogoSemi2;
                    }
                }

            }
            else if (equipa40 < equipa41)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoSemi2 + "      venceu!\n");
                jogoFinal1 = jogoSemi2;
            }
            Console.ForegroundColor = ConsoleColor.White;



            Console.ForegroundColor = ConsoleColor.DarkGray;
            Console.WriteLine("\n     SEMI SEGUNDA RODADA:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoSemi3 + " vs " + jogoSemi4);


            Random random10014 = new Random();
            // Armazena os gols de cada equipe
            int equipa42 = 0;
            int equipa43 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10014 = random10014.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10014 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa42++;
                }
                else if (randomNumber10014 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa43++;
                }
            }


            Console.WriteLine("     " + jogoSemi3 + ": " + equipa42 + " - " + equipa43 + " :" + jogoSemi4);
            if (equipa42 > equipa43)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoSemi3 + "     venceu!\n");
                jogoFinal2 = jogoSemi3;
            }
            else if (equipa42 == equipa43)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndsemi2 = new Random();

                if (equipa42 == equipa43)
                {
                    int randomNumberSemi2 = rndsemi2.Next(0, 2);
                    if (randomNumberSemi2 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoSemi3 + " venceu as penalidades");
                        jogoFinal2 = jogoSemi3;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoSemi4 + " venceu as penalidades");
                        jogoFinal2 = jogoSemi4;
                    }
                }

            }
            else if (equipa42 < equipa43)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoSemi4 + "      venceu!\n");
                jogoFinal2 = jogoSemi4;
            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadLine();
            Console.Clear();
            Console.WriteLine(" ________________________                   ________________________                                                                                                                                                                                                  ");
            Console.WriteLine("|    Oitavas de Final    |                 |    Quartas de Final    |                                                                                                                                                                                                 ");
            Console.WriteLine("|------------------------|                 |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("                                                                                                                                                                                                                                                                      ");
            Console.WriteLine("|------------------------|                                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoA[1] + "                                                                                                                                                                                                                                                         ");
            Console.WriteLine("|           -            |--------------|                                                                                                                                                                                                                             ");
            Console.WriteLine("         " + GrupoB[0] + "                           |  |------------------------|                                                                                                                                                                                                 ");
            Console.WriteLine("|________________________|              |        " + jogoQuarta1 + "                                                                                                                                                                                                      ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |        " + jogoQuarta2 + "                   |               ________________________                                                                                                                                           ");
            Console.WriteLine("|------------------------|              |  |________________________|              |              |        Semi Finas      |                                                                                                                                          ");
            Console.WriteLine("         " + GrupoC[1] + "                          |                                          |              |------------------------|                                                                                                                                          ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("                                                                                   |                    " + jogoSemi1 + "                                                                                                                                               ");
            Console.WriteLine("                                                                                   ---------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |                    " + jogoSemi2 + "                            |                                                                                                                  ");
            Console.WriteLine("                                                                                   |              |________________________|                       |      ________________________                                                                                    ");
            Console.WriteLine("|------------------------|                                                         |                                                               |     |          Finas         |                             _______________________                               ");
            Console.WriteLine("         " + GrupoE[1] + "                                                                  |                                                      |     |------------------------|                            |        Vencedor       |                              ");
            Console.WriteLine("|           -            |---------------|                                         |                                                               |         " + jogoFinal1 + "                                 |-----------------------|                              ");
            Console.WriteLine("         " + GrupoF[0] + "                        |  |------------------------|             |                                                      ------|           -            | ---------------------------|      Classificado     |                              ");
            Console.WriteLine("|________________________|               |        " + jogoQuarta3 + "                   |                                                                    " + jogoFinal2 + "                                  |_______________________|                              ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                               |     |________________________|                                                                                   ");
            Console.WriteLine("                                         |        " + jogoQuarta4 + "                                                                                   |                                                                                                                  ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                             |                                                                                                                  ");
            Console.WriteLine("         " + GrupoG[1] + "                           |                                                                                                         |                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                                                                                         |                                                                                                                  ");
            Console.WriteLine("         " + GrupoH[0] + "                                                                                                                                     |                                                                                                                  ");
            Console.WriteLine("|________________________|                                                                        |________________________|                       |                                                                                                                  ");
            Console.WriteLine("                                                                                                        " + jogoSemi3 + "                            |                                                                                                                  ");
            Console.WriteLine("                                                                                   |--------------|           -            |-----------------------|                                                                                                                  ");
            Console.WriteLine("                                                                                   |                    " + jogoSemi4 + "                                                                                                                                               ");
            Console.WriteLine("|------------------------|                                                         |              |________________________|                                                                                                                                          ");
            Console.WriteLine("         " + GrupoB[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |--------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoA[0] + "                          |  |------------------------|              |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|              |        " + jogoQuarta5 + "                    |                                                                                                                                                                                  ");
            Console.WriteLine("                                        ---|           -            |--------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                        |        " + jogoQuarta6 + "                    |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|              |  |________________________|              |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoD[1] + "                          |                                          |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            | -------------|                                          |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoC[0] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("                                                                                   |                                                                                                                                                                                  ");
            Console.WriteLine("|------------------------|                                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoF[1] + "                                                                     |                                                                                                                                                                                  ");
            Console.WriteLine("|           -            |---------------|                                         |                                                                                                                                                                                  ");
            Console.WriteLine("         " + GrupoE[0] + "                           |  |------------------------|             |                                                                                                                                                                                  ");
            Console.WriteLine("|________________________|               |  |      " + jogoQuarta7 + "      |             |                                                                                                                                                                                  ");
            Console.WriteLine("                                         ---|           -            |-------------|                                                                                                                                                                                  ");
            Console.WriteLine("                                         |  |      " + jogoQuarta8 + "      |                                                                                                                                                                                                ");
            Console.WriteLine("|------------------------|               |  |________________________|                                                                                                                                                                                                ");
            Console.WriteLine("         " + GrupoH[1] + "                           |                                                                                                                                                                                                                            ");
            Console.WriteLine("|           -            |---------------|                                                                                                                                                                                                                            ");
            Console.WriteLine("         " + GrupoG[0] + "                                                                                                                                                                                                                                                        ");
            Console.WriteLine("|________________________|                                                                                                                       ");
            Console.ReadLine();
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n     FINAL:");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n     " + jogoFinal1 + " vs " + jogoFinal2);



            Random random10015 = new Random();
            // Armazena os gols de cada equipe
            int equipa50 = 0;
            int equipa51 = 0;

            // Executa o jogo 10 vezes
            for (int i = 0; i < 5; i++)
            {
                // Sorteia um número aleatório entre 0 e 100
                int randomNumber10015 = random10015.Next(0, 101);

                // Verifica se o número sorteado é menor que 20, o que significa que houve poucas chances de marcar gols
                if (randomNumber10015 < 50)
                {
                    // Se o time A tiver chances de marcar, incrementa o número de gols
                    equipa50++;
                }
                else if (randomNumber10015 < 50)
                {
                    // Se o time B tiver chances de marcar, incrementa o número de gols
                    equipa51++;
                }
            }


            Console.WriteLine("     " + jogoFinal1 + ": " + equipa50 + " - " + equipa51 + " :" + jogoFinal2);
            if (equipa50 > equipa51)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoFinal1 + "     venceu!\n");
                jogoVencedor = jogoFinal1;
            }
            else if (equipa50 == equipa51)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("     Empate!\n");
                Console.WriteLine("     O jogo íra para penalidades:\n");

                Random rndfina1 = new Random();

                if (equipa50 == equipa51)
                {
                    int randomNumberfina1 = rndfina1.Next(0, 2);
                    if (randomNumberfina1 == 0)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoFinal1 + " venceu as penalidades");
                        jogoVencedor = jogoFinal1;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("      " + jogoFinal2 + " venceu as penalidades");
                        jogoVencedor = jogoFinal2;
                    }
                }

            }
            else if (equipa50 < equipa51)
            {
                Console.Write("     Resultado: ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(jogoFinal2 + "      venceu!\n");
                jogoVencedor = jogoFinal2;
            }
            Console.ForegroundColor = ConsoleColor.White;

            Console.ReadLine();
            Console.Clear();


            Console.WriteLine("E o vencedor foi: " + jogoVencedor);
            Console.ReadLine();

        }

       
    }
}






                   